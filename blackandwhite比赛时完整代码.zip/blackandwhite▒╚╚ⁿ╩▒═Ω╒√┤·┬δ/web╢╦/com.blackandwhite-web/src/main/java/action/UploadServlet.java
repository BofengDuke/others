package action;


import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.json.simple.JSONObject;

import model.SingalFileDao;
import utils.DBUtil;
import utils.Grobal;

import com.aliyun.oss.ClientException;
import com.aliyun.oss.OSSClient;
import com.aliyun.oss.OSSException;
import com.aliyun.oss.model.CompleteMultipartUploadResult;
import com.aliyun.oss.model.PutObjectRequest;
import com.aliyun.oss.model.UploadFileRequest;
import com.aliyun.oss.model.UploadFileResult;


/**
 * Servlet implementation class UploadServlet
 */
@WebServlet("/UploadServlet")
public class UploadServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	// 上传配置
	private static final int MEMORY_THRESHOLD 	= 1024 * 1024 * 20;		// 20MB
	private static final int MAX_FILE_SIZE 		= 1024 * 1024 * 20;		
	private static final int MAX_REQUEST_SIZE 	= 1024 * 1024 * 30;		
	
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UploadServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * 上传数据及保存文件
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("application/json;charset=utf-8");
		JSONObject jsonObj = new JSONObject();

		// 检测是否为多媒体上传
		if(!ServletFileUpload.isMultipartContent(request)){
			jsonObj.put("error", " 表单必须包含enctype=multipart/form-data");
			response.getWriter().println(jsonObj);
			return;
		}
		
		// 配置上传参数
		DiskFileItemFactory factory = new DiskFileItemFactory();
		// 设置内存临界值
		factory.setSizeThreshold(MEMORY_THRESHOLD);
		// 设置临时存储目录
		factory.setRepository(new File(System.getProperty("java.io.tmpdir")));
		
		ServletFileUpload upload = new ServletFileUpload(factory);
		
		// 设置最大文件上传值
		upload.setFileSizeMax(MAX_FILE_SIZE);
		
		// 设置最大请求值(包含文件和表单数据)
		upload.setSizeMax(MAX_REQUEST_SIZE);
		
		// 中文处理
		upload.setHeaderEncoding("UTF-8");
		
		// 构造临时路径来存储上传的文件
		// 路径是相对当前应用的目录
		String uploadPath = getServletContext().getRealPath("./")+ Grobal.UPLOAD_FILE_DIR;
		
		//如果目录不存在，则创建
		File uploadDir = new File(uploadPath);
		if(!uploadDir.exists()){
			uploadDir.mkdir();
		}
		Connection conn= null;
		
		try {
			// 解析请求的内容，提取文件数据
			List<FileItem> formItems = upload.parseRequest(request);
	
			// 打开数据库连接
			DBUtil db = new DBUtil();
			conn = db.getConnect();
			
			String timeStamp = null;
			String uuid = null;
			if (formItems != null && formItems.size() > 0) {
				// 迭代表单数据
				for (FileItem item : formItems) {
					String keySuffixWithSlash = "OMP/input/";
					
					// 处理不在表单中的字段
					if (!item.isFormField()) {
						System.out.println(item.getName());
						if(!item.getName().equals("yMatrix.json")){
							jsonObj.put("error", "不是正确的文件");
							response.getWriter().println(jsonObj);
						}else{
							uuid = UUID.randomUUID().toString().toUpperCase();
							String fileName = new File(item.getName()).getName();
							String suffix = fileName.substring(fileName.lastIndexOf(".")+1);
							String filePath = uploadPath + File.separator + uuid+"."+suffix;
							File storeFile = new File(filePath);
							// 在控制台输出文件的上传路径
							// 保存文件到硬盘
							item.write(storeFile);
							timeStamp = String.valueOf(System.currentTimeMillis()) ;
							
							SingalFileDao singalFileDao = new SingalFileDao(conn);
							singalFileDao.setSignalFile(fileName, filePath, uuid, timeStamp);
							
							// 上传到OSS中
							String fileKey = keySuffixWithSlash + uuid+ "/"+ fileName;	// OMP/input/uuid/yMatrix.json
							OSSClient ossClient = new OSSClient(Grobal.OSS_Endpoint, Grobal.ACCESS_KEY_ID, Grobal.ACCESS_KEY_SECRET);
							ossClient.putObject(new PutObjectRequest(Grobal.BUCKET_NAME, fileKey, storeFile));
	
							jsonObj.put("uuid", uuid);
							response.getWriter().println(jsonObj);
							System.out.println("Upload Success!");
						}
					}
				}
			}
			
			DBUtil.getClose(conn);
			
		} catch (SQLException e) {
			e.printStackTrace();
			jsonObj.put("error", "数据库连接错误，上传失败");
			response.getWriter().println(jsonObj);
			
		} catch ( Exception e) {
			e.printStackTrace();
			jsonObj.put("error", "服务器异常，上传失败");
			response.getWriter().print(jsonObj);
		}
		

	}	

}
