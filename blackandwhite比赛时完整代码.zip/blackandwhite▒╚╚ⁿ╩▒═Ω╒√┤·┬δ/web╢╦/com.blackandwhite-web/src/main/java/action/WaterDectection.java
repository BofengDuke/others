package action;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Random;

import org.apache.mahout.math.Matrix;
import org.apache.mahout.math.SparseMatrix;

import net.sf.json.JSONObject;
import utils.Grobal;

public class WaterDectection {

	private static int RANGE_WATER_DETECT = 10;
	/**
	 * @param Xi_Yi
	 * @param Wi_Zi
	 * @return 计算水印统计测量值q/qcs
	 */
	public static double[] calcOriginalQorQcs(Matrix Xi_Yi, Matrix Wi_Zi){
		//将传入矩阵信号变为n维列向量信号
		Matrix signalXi_Yi = MatrixHelper.toSingleColumn(Xi_Yi);
		Matrix signalWi_Zi = MatrixHelper.toSingleColumn(Wi_Zi);
		
		if(signalWi_Zi.rowSize() != signalXi_Yi.rowSize())
			return null;
		
		int count = signalXi_Yi.rowSize();//信号规模
		double mc = 0;
		double vc = 0;
		
		//计算Mc/Mc'
		double Xi_YiTimesWi_Zi[] = new double[count];
		for(int i = 0; i < count; i++){
			Xi_YiTimesWi_Zi[i] = signalXi_Yi.get(i, 0)*signalWi_Zi.get(i, 0);
			mc = mc + Xi_YiTimesWi_Zi[i];
		}
		
		mc = mc/count;
		
		//计算Vc/Vc'
		for(int j = 0; j < count; j++){
			double temp = (Xi_YiTimesWi_Zi[j] - mc)*(Xi_YiTimesWi_Zi[j] - mc);
			vc = vc + temp;
		}
		
		vc = Math.sqrt(vc / (count-1));
		//计算q/qcs
		double q = Math.sqrt(count)*mc/vc;
		double result[] = {mc,vc,q};
		return result;
	}
	
	
	public static Matrix formWaterMatrix(int imgWidth) {
		Matrix resultWaterMatrix = new SparseMatrix(imgWidth,imgWidth);
		for(int i = 0; i < imgWidth; i++){
			for(int j = 0; j < imgWidth; j++){
				Random ranWateri = new Random();
				int wi = ranWateri.nextInt(2);
				if(wi==1){
					resultWaterMatrix.set(i, j, 1);
				}
				else
					resultWaterMatrix.set(i, j, -1);	
			}
		}
		return resultWaterMatrix;
	}  

	/**
	 * 将字符串序列转化为01序列
	 * @param str
	 * @return bit stream of str
	 */
	private static String StrToBinstr(String str) {
        char[] strChar=str.toCharArray();
        String result="";
        for(int i=0;i<strChar.length;i++){
            result +=Integer.toBinaryString(strChar[i]);
        }
        return result;
    }
	
	/**
	 * 根据水印信息（用户输入的密钥类型的水印字符串）生成1/-1序列的字符串
	 * @param waterMark
	 * @param sizeOfImage
	 * @return waterMarkSequence
	 */
	public static double[] getWaterMarkSequence(String waterMark, int sizeOfImage){
		String bitWater = StrToBinstr(waterMark);
		char[] bitWaterArr = bitWater.toCharArray();
		
		int finalSizeOfWaterSequence = (sizeOfImage)*(sizeOfImage);//最终水印序列与原图规模一样
		int lenOfWaterArr = bitWaterArr.length;//取水印序列长度
		double[] bitWaterFinal = new double[finalSizeOfWaterSequence];
		
		if(lenOfWaterArr > finalSizeOfWaterSequence){//水印长度小于最终要求序列大小
			
			for(int i = 0; i < finalSizeOfWaterSequence; i++){
				if(bitWaterArr[i] =='0')
					bitWaterFinal[i] = -1;
				else
					bitWaterFinal[i] = 1;
			}
		}
		else{
			//将输入的水印信息重复排列为规定长度的水印信号
			int times = finalSizeOfWaterSequence/lenOfWaterArr;
			String bitWaterTemp =  "";
			for(int j = 0; j < times; j++){
				bitWaterTemp += bitWater;
			}
			
			int tempSizeOfbitWaterTemp = bitWaterTemp.length();
			for(int k = 0; k < finalSizeOfWaterSequence - tempSizeOfbitWaterTemp; k++){
				bitWaterTemp = bitWaterTemp + bitWaterArr[k];
			}
			
			char[] bitWaterTempArr = bitWaterTemp.toCharArray();
			for(int i = 0; i < finalSizeOfWaterSequence; i++){
				if(bitWaterTempArr[i] =='0')
					bitWaterFinal[i] = -1;
				else
					bitWaterFinal[i] = 1;
			}	
		}
		return bitWaterFinal;
	}
	

/**
	 * 计算1000次q/qcs统计值
	 * @param Xi_Yi 稀疏信号
	 * @param signalLength 信号规模
	 * @param strength 嵌入力度
	 * @param Phi 观测矩阵Phi
	 */
	public static void calcQ(Matrix Xi_Yi,int signalLength, int strength, Matrix Phi){
		int testLen = 1000;
		double [] H0_Q = new double[testLen];
		double [] H1_Q = new double[testLen];
		double [] H0_Qcs = new double[testLen];
		double [] H1_Qcs = new double[testLen];
		Matrix matrixH0_Q = new SparseMatrix(testLen, 1);
		Matrix matrixH1_Q = new SparseMatrix(testLen, 1);
		Matrix matrixH0_Qcs = new SparseMatrix(testLen, 1);
		Matrix matrixH1_Qcs = new SparseMatrix(testLen, 1);
		

	    //H0--q
		for(int i = 0; i < testLen; i++){
			Matrix detectWaterMatrix =  formWaterMatrix(signalLength);
			//MatrixHelper.printMatrix(detectWaterMatrix);	
			
			H0_Q[i] =  calcOriginalQorQcs(Xi_Yi, detectWaterMatrix)[2];
			matrixH0_Q.set(i, 0, H0_Q[i]);
		}
		//H1--q
		for(int i = 0; i < testLen; i++){
			Matrix detectWaterMatrix =  formWaterMatrix(signalLength);
			//MatrixHelper.printMatrix(detectWaterMatrix);	
			double [][] wateredSignal =  getSignalWithWaterMark(MatrixHelper.matrixToDouble(Xi_Yi), MatrixHelper.matrixToDouble(detectWaterMatrix), strength);
			H1_Q[i] =  calcOriginalQorQcs(MatrixHelper.doubleToMatrix(wateredSignal), detectWaterMatrix)[2];
			matrixH1_Q.set(i, 0, H1_Q[i]);
		}
		//H0--qcs
		for(int i = 0; i < testLen; i++){
			Matrix detectWaterMatrix =  formWaterMatrix(signalLength);
			Matrix tempXi_Yi = Phi.times(Xi_Yi);
			Matrix tempWaterMatrix = Phi.times(detectWaterMatrix);
			H0_Qcs[i] =  calcOriginalQorQcs(tempXi_Yi, tempWaterMatrix)[2];
			matrixH0_Qcs.set(i, 0, H0_Qcs[i]);
		}
		//H1--qcs
		for(int i = 0; i < testLen; i++){
			Matrix detectWaterMatrix =  formWaterMatrix(signalLength);
			Matrix tempWaterMatrix = Phi.times(detectWaterMatrix);
		
			double [][] wateredSignal =  getSignalWithWaterMark(MatrixHelper.matrixToDouble(Xi_Yi), MatrixHelper.matrixToDouble(detectWaterMatrix), strength);
			Matrix tempXi_Yi = Phi.times(MatrixHelper.doubleToMatrix(wateredSignal));
			
			H1_Qcs[i] = calcOriginalQorQcs(tempXi_Yi, tempWaterMatrix)[2];
			matrixH1_Qcs.set(i, 0, H1_Qcs[i]);
			//System.out.println(matrixH1_Qcs.get(i, 0));
		}

	}

	/**
	 * 对稀疏信号进行水印嵌入
	 * @param sparaseSignal
	 * @param waterMark
	 * @param strength
	 * @return watered sparase signal
	 */
	public static double[][] getSignalWithWaterMark(double[][]sparaseSignal,double[][] waterMark,int strength){

		double[][] resultSparaseWateredSignal = new double[sparaseSignal.length][sparaseSignal.length];
		for(int i = 0; i < sparaseSignal.length; i++){
			for(int j = 0; j < sparaseSignal.length; j++){
				resultSparaseWateredSignal[i][j] = sparaseSignal[i][j] + waterMark[i][j]*strength;
			}
		}
		return resultSparaseWateredSignal;
	}
	
	/**
	 * 读取文件内容
	 * @param jsonfile
	 * @return file contents
	 */
	public static String fileContents(File jsonfile){
		String lastArr = "";
		 try {  
	            BufferedReader br = new BufferedReader(new FileReader(jsonfile));// 读取原始json文件   
	            String s = null; 
	            while ((s = br.readLine()) != null) {  
	            	lastArr += s;
	            }  	 
	            br.close();  	  
	        } catch (IOException e) {  
	            e.printStackTrace();  
	        }
		 return lastArr;
	}
	/**
	 * 身份认证
	 * @param yMatrix 云端保存的测量值Y文件
	 * @param waterCs 用户上传的水印文件&加密的Phi
	 * @return 是否通过水印身份认证
	 */
	public static boolean isWaterDetected(File yMatrix, File waterCs){
		 int Tq = RANGE_WATER_DETECT ;
		 JSONObject  jsonObjY  = JSONObject.fromObject(fileContents(yMatrix));		 
		 Matrix tempY = new SparseMatrix(Grobal.DEFAULT_BLOCKSIZE,Grobal.DEFAULT_BLOCKSIZE);
		 String temp = jsonObjY.getString(Integer.toString(2));		 
		 String[] rowValues = temp.split("\n");
		 for(int j=0; j<rowValues.length; j++){
			 String[] colValues = rowValues[j].split("\t");
			 for(int k=0; k<colValues.length; k++){
				 tempY.set(j, k, Double.parseDouble(colValues[j]));
			 }	
		 }
		 JSONObject  jsonObjW  = JSONObject.fromObject(fileContents(waterCs));		 
		 Matrix tempW = new SparseMatrix(Grobal.DEFAULT_BLOCKSIZE,Grobal.DEFAULT_BLOCKSIZE);
		 String temp1 = jsonObjW.getString("watermark");		 
		 String[] rowValues1 = temp1.split("\n");
		 for(int j=0; j<rowValues1.length; j++){
			 String[] colValues1 = rowValues1[j].split("\t");
			 for(int k=0; k<colValues1.length; k++){
				 tempW.set(j, k, Double.parseDouble(colValues1[j]));
			 }	
		 }
		 
		 double tempQcs = calcOriginalQorQcs(tempY, tempW)[2];
		 if(tempQcs>Tq){
			 return true;
		 }
		 else
			 return false;
		
	}

	public static void main(String[] args) throws Exception {	
		boolean a = isWaterDetected(new File("C:\\Users\\Bofeng Duke\\Desktop\\CS_Workshop\\file\\proEncrypt.json"), new File("C:\\Users\\Bofeng Duke\\Desktop\\CS_Workshop\\file\\yMatrix.json"));
		System.out.println(a);
	}	
	
}
