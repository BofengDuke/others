package action;

import java.awt.print.Printable;
import java.io.IOException;
import java.security.Signature;
import java.sql.Connection;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONObject;

import model.SingalFile;
import model.SingalFileDao;
import utils.DBUtil;


/**
 * Servlet implementation class SearchServlet
 */
@WebServlet("/SearchServlet")
public class SearchServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SearchServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String uuid = request.getParameter("uuid");
		
		DBUtil db = new DBUtil();
		try {
			Connection conn = db.getConnect();
			SingalFileDao singalFileDao = new SingalFileDao(conn);
			SingalFile singalFile = singalFileDao.getSingalFile(uuid);
			
			DBUtil.getClose(conn);

			JSONObject jsonObject = new JSONObject();
			jsonObject.put("name", singalFile.getName());
			jsonObject.put("uuid", singalFile.getUuid());
			
			response.setContentType("application/json;charset=utf8");
			response.getWriter().print(jsonObject);
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
