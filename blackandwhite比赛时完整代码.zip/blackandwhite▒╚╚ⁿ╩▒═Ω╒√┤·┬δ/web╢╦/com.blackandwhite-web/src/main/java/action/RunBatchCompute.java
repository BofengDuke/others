package action;

import java.io.File;

import com.aliyuncs.batchcompute.main.v20151111.BatchCompute;
import com.aliyuncs.batchcompute.main.v20151111.BatchComputeClient;
import com.aliyuncs.batchcompute.model.v20151111.CreateJobResponse;
import com.aliyuncs.batchcompute.pojo.v20151111.Command;
import com.aliyuncs.batchcompute.pojo.v20151111.DAG;
import com.aliyuncs.batchcompute.pojo.v20151111.InputMappingConfig;
import com.aliyuncs.batchcompute.pojo.v20151111.JobDescription;
import com.aliyuncs.batchcompute.pojo.v20151111.Notification;
import com.aliyuncs.batchcompute.pojo.v20151111.Parameters;
import com.aliyuncs.batchcompute.pojo.v20151111.TaskDescription;
import com.aliyuncs.batchcompute.pojo.v20151111.Topic;
import com.aliyuncs.exceptions.ClientException;

import utils.Grobal;

public class RunBatchCompute {
	
	public static void  runBatchCompute(String uuid,File yMatrixJson,File proEncryptJson) {
		 BatchCompute client = new BatchComputeClient("cn-shenzhen", Grobal.ACCESS_KEY_ID, Grobal.ACCESS_KEY_SECRET);
//		 try {
//	            JobDescription jobDescription = getJobDesc(uuid, instanceNum);
//	            CreateJobResponse response = client.createJob(jobDescription);
//	            String jobId = response.getJobId();
//	            //创建成功
//	            System.out.println("Got job id:" + jobId);
//	        } catch (ClientException e) {
//	            e.printStackTrace();
//	            //创建失败
//	        }
		
	}
	
	public static JobDescription getJobDesc(String uuid,int instanceNum){
		JobDescription jobDesc = new JobDescription();
		jobDesc.setName("runOMP");
		jobDesc.setPriority(1);
		jobDesc.setDescription("runOMP");
		jobDesc.setType("DAG");
        jobDesc.setJobFailOnInstanceFail(true);
        jobDesc.setAutoRelease(false);
        
        DAG dag = new DAG();
        TaskDescription ompTask =  getTaskDesc(Grobal.DEFAULT_CLUSTER_ID);
        ompTask.getParameters().getCommand().setCommandLine("python OMP.py " + uuid);
        dag.addTask(ompTask);
        jobDesc.setDag(dag);
        Notification noti = new Notification();
        Topic topic = new Topic();
        topic.addEvent(Topic.ON_JOB_FAILED);
        topic.addEvent(Topic.ON_JOB_FINISHED);
        noti.setTopic(topic);
        topic.setName("tp_n1");

		return jobDesc;
	}
	
	private static TaskDescription getTaskDesc(String clusterId){
		TaskDescription task = new TaskDescription();
		task.setClusterId(clusterId);
		task.setInstanceCount(1);
        task.setMaxRetryCount(1);
        task.setTaskName("runRestruct");
        task.setTimeout(60*10);
        Command cmd = new Command();
//        cmd.setCommandLine("python OMP.py " + uuid );
        cmd.setPackagePath(Grobal.WORKER_PATH);
        Parameters parameters = new Parameters();
        parameters.setCommand(cmd);
        parameters.setStderrRedirectPath(Grobal.LOG_PATH);
        parameters.setStdoutRedirectPath(Grobal.LOG_PATH);
        InputMappingConfig input = new InputMappingConfig();
        input.setLock(true);
        parameters.setInputMappingConfig(input);
        task.setParameters(parameters);
        task.addInputMapping(Grobal.INPUT_PATH, "/home/input/");
        task.addOutputMapping("/home/output/", Grobal.OUTPUT_PATH);
        

		return task;
	}
	

	
	
}
