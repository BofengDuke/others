package action;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.json.simple.JSONObject;

import com.aliyun.oss.OSSClient;
import com.aliyun.oss.model.GetObjectRequest;
import com.aliyun.oss.model.PutObjectRequest;
import com.aliyuncs.batchcompute.main.v20151111.BatchCompute;
import com.aliyuncs.batchcompute.main.v20151111.BatchComputeClient;
import com.aliyuncs.batchcompute.model.v20151111.CreateJobResponse;
import com.aliyuncs.batchcompute.pojo.v20151111.JobDescription;
import com.aliyuncs.exceptions.ClientException;

import model.SingalFileDao;
import utils.Grobal;

/**
 * Servlet implementation class CheckWaterAndRestruct
 */
@WebServlet("/CheckWaterAndRestruct")
public class CheckWaterAndRestruct extends HttpServlet {
	private static final long serialVersionUID = 1L;
      
	/**
     * @see HttpServlet#HttpServlet()
     */
    public CheckWaterAndRestruct() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
//	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		// TODO Auto-generated method stub
//		response.getWriter().append("Served at: ").append(request.getContextPath());
//	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	@SuppressWarnings("unchecked")
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		response.setContentType("application/json;charset=utf-8");
		// 获取上传的proEncript文件
		JSONObject jsonObj = new JSONObject();
		// 配置上传参数
		DiskFileItemFactory factory = new DiskFileItemFactory();
		// 设置内存临界值
		factory.setSizeThreshold(Grobal.MEMORY_THRESHOLD);
		// 设置临时存储目录
		factory.setRepository(new File(System.getProperty("java.io.tmpdir")));

		
		// 检测是否为多媒体上传
		if(!ServletFileUpload.isMultipartContent(request)){
			jsonObj.put("error", " 表单必须包含enctype=multipart/form-data");
			response.getWriter().println(jsonObj);
			return;
		}
		
		ServletFileUpload upload = new ServletFileUpload(factory);
		// 中文处理
		upload.setHeaderEncoding("UTF-8");

		String uploadPath = getServletContext().getRealPath("./")+ Grobal.UPLOAD_FILE_DIR;
		uploadPath = uploadPath + "/tmp";
		File uploadDir = new File(uploadPath);
		if(!uploadDir.exists()){
			uploadDir.mkdirs();
		}
		
		// 获取 phi及水印文件
		String uuid = "";
		File proEncryptJson = null;
		try{
			List<FileItem> formItems = upload.parseRequest(request);
			
			if (formItems != null && formItems.size() > 0) {
				for (FileItem item : formItems) {
					if (!item.isFormField()) {
						if (item.getName().equals("proEncrypt.json")) {
							String fileName = new File(item.getName()).getName();
							String filePath = uploadPath + File.separator + fileName;
							proEncryptJson = new File(filePath);
							item.write(proEncryptJson);
						}else {
							jsonObj.put("error", "不是正确的文件");
							response.getWriter().println(jsonObj);
						}

					}else{
						uuid = item.getString();
						System.out.println(uuid);
					}
				}
			}

		} catch ( Exception e) {
			e.printStackTrace();
			jsonObj.put("error", "服务器异常");
			response.getWriter().print(jsonObj);
		}
		
		
		
		
		// 根据UUID值，从OSS系统中获取yMatrix.json文件
		File yMatrixJson = new File(uploadPath+"/"+"yMatrix.json");
		String filePath = "OMP/input/"+uuid+"/yMatrix.json";
		OSSClient ossClient = new OSSClient(Grobal.OSS_Endpoint, Grobal.ACCESS_KEY_ID, Grobal.ACCESS_KEY_SECRET);
		ossClient.getObject(new GetObjectRequest(Grobal.BUCKET_NAME, filePath), yMatrixJson);
		
		
		System.out.println("check watermark");
		// 进行水印验证
		boolean isSuccess = WaterDectection.isWaterDetected(yMatrixJson,proEncryptJson);
		System.out.println(isSuccess);
		if(!isSuccess){
			jsonObj.put("error", "水印验证失败！");
			response.getWriter().println(jsonObj);
			return;
		}
		
		// 将proEncrypt存储到OSS中
		String filekey = "OMP/input/"+uuid+"/proEncrypt.json";
		ossClient.putObject(new PutObjectRequest(Grobal.BUCKET_NAME, filekey, proEncryptJson));
		
		// 解析yMatrix ，将建立多个实例进行重构 
		// 暂时省略
		

		// 进行重构
		
		BatchCompute client = new BatchComputeClient("cn-shenzhen", Grobal.ACCESS_KEY_ID, Grobal.ACCESS_KEY_SECRET);
        try {
            JobDescription jobDescription = RunBatchCompute.getJobDesc(uuid,2);
            CreateJobResponse jobResponse = client.createJob(jobDescription);
            String jobId = jobResponse.getJobId();
            //创建成功
            System.out.println("Got job id:" + jobId);
            
         // 成功让云进行重构
    		jsonObj.put("success", "已经交给云重构，请稍后进行下载");
    		response.getWriter().println(jsonObj);
        } catch (ClientException e) {
            e.printStackTrace();
            //创建失败
            System.out.println(e);
        }
		
		
		
		

		
	}

}
