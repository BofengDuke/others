package action;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.aliyun.oss.OSSClient;
import com.aliyun.oss.model.GetObjectRequest;

import utils.Grobal;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import javax.servlet.annotation.WebServlet;

/**
 * Servlet implementation class DownloadServlet
 */
@WebServlet("/DownloadServlet")
public class DownloadServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DownloadServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String uuid = request.getParameter("uuid");
		String filePath = "OMP/output/"+uuid+"/encryptS.json";
		String basePath = request.getSession().getServletContext().getRealPath("/download");
		String filename = "encryptS.json";
		
		System.out.println(uuid);
		System.out.println(filePath);
		
		File dir = new File(basePath+"/"+uuid+"/");
		if(!dir.exists()){
			dir.mkdirs();
		}
		
		try{
			OSSClient ossClient = new OSSClient(Grobal.OSS_Endpoint, Grobal.ACCESS_KEY_ID, Grobal.ACCESS_KEY_SECRET);
			ossClient.getObject(new GetObjectRequest(Grobal.BUCKET_NAME, filePath), new File(basePath+"/"+uuid+"/"+filename));

		}catch (Exception e) {
			System.out.println("File is not exist!");
			request.setAttribute("message", "文件不存在");
			getServletContext().getRequestDispatcher("/message.jsp").forward(request, response);
		}
		
		
		// 下载文件
		String fileDownload = basePath + File.separator+ uuid + File.separator + filename;
		
		File file = new File(fileDownload);
		if(!file.exists() || "".equals(filename)){
			request.setAttribute("message", "文件不存在");
			getServletContext().getRequestDispatcher("/message.jsp").forward(request, response);
		}
		
		response.setContentType(getServletContext().getMimeType(filename));
		response.setContentType("application/x-download");
		response.addHeader("Content-Disposition", "attachment;filename="+filename);
		long fileLength = file.length();
		response.setHeader("Content-Length", String.valueOf(fileLength));
		
		
		InputStream is = null;
		OutputStream os = null;
		BufferedInputStream bis = null;
		BufferedOutputStream bos = null;
		
		try{
			is = new FileInputStream(new File(fileDownload));
			bis = new BufferedInputStream(is);
			os = response.getOutputStream();
			bos = new BufferedOutputStream(os);
		
			byte[] buff = new byte[1024];
			int len = 0;
			while((len = bis.read(buff)) != -1 ){
				bos.write(buff,0,len);
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			if(bis != null)
				bis.close();
			
			if(is != null)
				is.close();
			
			if(bos != null)
				bos.close();
			
			if(os != null)
				os.close();

		}
		
		System.out.println("end");
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
	}

}
