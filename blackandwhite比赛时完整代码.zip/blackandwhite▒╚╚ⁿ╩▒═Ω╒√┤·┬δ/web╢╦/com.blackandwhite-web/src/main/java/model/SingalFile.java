package model;

public class SingalFile {
	private String name;
	private String path;
	private String timeStamp;
	private String uuid;
	
	public SingalFile() {
		super();
	}
	
	public SingalFile(String name,String path,String uuid,String timeStamp){
		super();
		this.name = name;
		this.path = path;
		this.uuid = uuid;
		this.timeStamp = timeStamp;
		
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public String getTimeStamp() {
		return timeStamp;
	}

	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}


	
}
