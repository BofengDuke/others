package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class SingalFileDao {
	
	private Connection conn;
	
	public SingalFileDao( Connection conn) {
		this.conn = conn;
	}
	
	public SingalFile getSingalFile(String uuid) throws SQLException {
		String sql = "select * from signal_file where uuid = ?";
		PreparedStatement ppsm = conn.prepareStatement(sql);
		ppsm.setString(1, uuid);
		
		SingalFile singalFile = null;
		ResultSet rSet = ppsm.executeQuery();
		if(rSet.next()){
			String name = rSet.getString("name");
			String path = rSet.getString("path");
			String uuidTmp = rSet.getString("uuid");
			String timeStamp = rSet.getString("timestamp");
			singalFile = new SingalFile(name,path,uuidTmp,timeStamp);
		}
		return singalFile;
	}
	
	public void setSignalFile(String name,String path,String uuid,String timeStamp) throws SQLException{
		String sql = "INSERT into signal_file (name,path,uuid,timestamp) values(?,?,?,?) ";
		PreparedStatement ppsm = conn.prepareStatement(sql);
		ppsm.setString(1, name);
		ppsm.setString(2, path);
		ppsm.setString(3, uuid);
		ppsm.setString(4, timeStamp);
		
		ppsm.execute();

	}
	
}
