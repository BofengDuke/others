package utils;

public class Grobal {
	
	// 文件上传配置
	public static final int MEMORY_THRESHOLD 	= 1024 * 1024 * 30;		// 30MB
	public static final int MAX_FILE_SIZE 		= 1024 * 1024 * 30;		
	public static final int MAX_REQUEST_SIZE 	= 1024 * 1024 * 30;		
	
	public static String UPLOAD_FILE_DIR = "/upload";									// 本地上传位置
	
	
	public static String REGION_ID = "cn-shenzhen";   									//这里填写region
    public static String ACCESS_KEY_ID = "";  							// 这里填写您的AccessKeyId
    public static String ACCESS_KEY_SECRET = ""; 		// 这里填写您的AccessKeySecret
    public static String OSS_Endpoint = "http://oss-cn-shenzhen.aliyuncs.com";
    
    public static String BUCKET_NAME = "blackandwhite";
    public static String WORKER_PATH = "oss://blackandwhite/OMP/OMP.tar.gz"; 			// 这里填写您上传的worker.tar.gz的OSS存储路径
    public static String LOG_PATH = "oss://blackandwhite/OMP/logs/"; 					//  这里填写您创建的错误反馈和task输出的OSS存储路径
    public static String UPLOAD_PATH = "oss://blackandwhite/OMP/upload/";  			// 上传的文件存放处
    public static String  INPUT_PATH = "oss://blackandwhite/OMP/input/";
    public static String OUTPUT_PATH = "oss://blackandwhite/OMP/output/";				// 重构结果输出的路径
    public static String MOUNT_PATH = "oss://blackandwhite/OMP/";						// 挂载的地方
    
    public static String DEFAULT_CLUSTER_ID = "cls-dduqvmn1llis2jfsjve00r";	// 默认集群
    
    
    public static  int DEFAULT_BLOCKSIZE = 64;		//默认图片分开大小
    
//    static String 
    
    
    
}
