package utils;

import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Connection;

public class DBUtil {
	private String url = "jdbc:mysql://localhost:3306/blackandwhite";
	private String user = "root";
	private String password = "bofengduke";
	private String driver = "com.mysql.jdbc.Driver";
	
	public Connection getConnect() throws ClassNotFoundException, SQLException{
		Class.forName(driver);
		Connection connection = DriverManager.getConnection(url,user,password);
		return connection;
	}
	
	public static void getClose(Connection connection) throws SQLException {
		if(connection != null){
			connection.close();
		}
	}
}
	