/*
Navicat MySQL Data Transfer

Source Server         : localhost
Source Server Version : 50714
Source Host           : localhost:3306
Source Database       : blackandwhite

Target Server Type    : MYSQL
Target Server Version : 50714
File Encoding         : 65001

Date: 2017-08-14 10:59:36
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for signal_file
-- ----------------------------
DROP TABLE IF EXISTS `signal_file`;
CREATE TABLE `signal_file` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `timestamp` varchar(255) NOT NULL,
  PRIMARY KEY (`id`,`uuid`)
) ENGINE=MyISAM AUTO_INCREMENT=85 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of signal_file
-- ----------------------------
INSERT INTO `signal_file` VALUES ('65', 'yMatrix.json', 'D:\\Program Files\\apache-tomcat-9.0.0.M21\\webapps\\wtpwebapps\\com.blackandwhite-web\\/upload\\8CEBAF46-9543-4916-AD58-D2405455AED7.json', '8CEBAF46-9543-4916-AD58-D2405455AED7', '1501006753211');
INSERT INTO `signal_file` VALUES ('66', 'yMatrix.json', 'D:\\Program Files\\apache-tomcat-9.0.0.M21\\webapps\\wtpwebapps\\com.blackandwhite-web\\/upload\\79CFB867-FEEC-4703-8C81-D4FD3125F32A.json', '79CFB867-FEEC-4703-8C81-D4FD3125F32A', '1501009730407');
INSERT INTO `signal_file` VALUES ('67', 'yMatrix.json', 'D:\\Program Files\\apache-tomcat-9.0.0.M21\\webapps\\wtpwebapps\\com.blackandwhite-web\\/upload\\3D1AC6EE-92C4-4472-A38D-D9F7F4C5D161.json', '3D1AC6EE-92C4-4472-A38D-D9F7F4C5D161', '1501034674012');
INSERT INTO `signal_file` VALUES ('68', 'yMatrix.json', 'D:\\Program Files\\apache-tomcat-9.0.0.M21\\webapps\\wtpwebapps\\com.blackandwhite-web\\/upload\\07C04394-66CB-4F61-9E8D-FE1110294B6F.json', '07C04394-66CB-4F61-9E8D-FE1110294B6F', '1501040450056');
INSERT INTO `signal_file` VALUES ('69', 'yMatrix.json', 'D:\\Program Files\\apache-tomcat-9.0.0.M21\\webapps\\wtpwebapps\\com.blackandwhite-web\\/upload\\83009921-F104-4BB8-BCE2-F8D7FCE26E21.json', '83009921-F104-4BB8-BCE2-F8D7FCE26E21', '1501041143600');
INSERT INTO `signal_file` VALUES ('70', 'yMatrix.json', 'D:\\Program Files\\apache-tomcat-9.0.0.M21\\webapps\\wtpwebapps\\com.blackandwhite-web\\/upload\\C3CF0D14-B329-41A7-977E-47A521F40603.json', 'C3CF0D14-B329-41A7-977E-47A521F40603', '1501041940840');
INSERT INTO `signal_file` VALUES ('71', 'yMatrix.json', 'D:\\Program Files\\apache-tomcat-9.0.0.M21\\webapps\\wtpwebapps\\com.blackandwhite-web\\/upload\\B02D1425-D1B2-4D13-847F-7A1A8773A5DD.json', 'B02D1425-D1B2-4D13-847F-7A1A8773A5DD', '1501043002527');
INSERT INTO `signal_file` VALUES ('72', 'yMatrix.json', 'D:\\Program Files\\apache-tomcat-9.0.0.M21\\webapps\\wtpwebapps\\com.blackandwhite-web\\/upload\\106A8D15-1D12-451A-B826-C9DC644CD89F.json', '106A8D15-1D12-451A-B826-C9DC644CD89F', '1501044355865');
INSERT INTO `signal_file` VALUES ('73', 'yMatrix.json', 'D:\\Program Files\\apache-tomcat-9.0.0.M21\\webapps\\wtpwebapps\\com.blackandwhite-web\\/upload\\2970E783-20B7-4F97-BFF8-5D342819280E.json', '2970E783-20B7-4F97-BFF8-5D342819280E', '1501044764987');
INSERT INTO `signal_file` VALUES ('74', 'yMatrix.json', 'D:\\Program Files\\apache-tomcat-9.0.0.M21\\webapps\\wtpwebapps\\com.blackandwhite-web\\/upload\\326DAEAD-FFB3-4E65-BB5F-E2FEDEBA7A58.json', '326DAEAD-FFB3-4E65-BB5F-E2FEDEBA7A58', '1501045382593');
INSERT INTO `signal_file` VALUES ('75', 'yMatrix.json', 'D:\\Program Files\\apache-tomcat-9.0.0.M21\\webapps\\wtpwebapps\\com.blackandwhite-web\\/upload\\5CC86B1B-00B6-4A4D-87A0-87E303A01DE3.json', '5CC86B1B-00B6-4A4D-87A0-87E303A01DE3', '1501046166355');
INSERT INTO `signal_file` VALUES ('76', 'yMatrix.json', 'D:\\Program Files\\apache-tomcat-9.0.0.M21\\webapps\\wtpwebapps\\com.blackandwhite-web\\/upload\\31B7A249-57B5-44F2-BF42-71C341E731B4.json', '31B7A249-57B5-44F2-BF42-71C341E731B4', '1501171875926');
INSERT INTO `signal_file` VALUES ('77', 'yMatrix.json', 'D:\\Program Files\\apache-tomcat-9.0.0.M21\\webapps\\wtpwebapps\\com.blackandwhite-web\\/upload\\7FA607B6-6436-48C9-B5D8-26BAAE172EF5.json', '7FA607B6-6436-48C9-B5D8-26BAAE172EF5', '1501174839440');
INSERT INTO `signal_file` VALUES ('78', 'yMatrix.json', 'D:\\Program Files\\apache-tomcat-9.0.0.M21\\webapps\\wtpwebapps\\com.blackandwhite-web\\/upload\\D25CA410-766F-4BB2-857C-D6C03B01A840.json', 'D25CA410-766F-4BB2-857C-D6C03B01A840', '1501207773691');
INSERT INTO `signal_file` VALUES ('79', 'yMatrix.json', 'D:\\Program Files\\apache-tomcat-9.0.0.M21\\webapps\\wtpwebapps\\com.blackandwhite-web\\/upload\\8664AA80-405E-4C47-A967-1ED41A5A8916.json', '8664AA80-405E-4C47-A967-1ED41A5A8916', '1501208641894');
INSERT INTO `signal_file` VALUES ('80', 'yMatrix.json', 'D:\\Program Files\\apache-tomcat-9.0.0.M21\\webapps\\wtpwebapps\\com.blackandwhite-web\\/upload\\D03CB4B7-6979-4606-A2F1-BBD5E5EFDF14.json', 'D03CB4B7-6979-4606-A2F1-BBD5E5EFDF14', '1501209195309');
INSERT INTO `signal_file` VALUES ('81', 'yMatrix.json', 'D:\\Program Files\\apache-tomcat-9.0.0.M21\\webapps\\wtpwebapps\\com.blackandwhite-web\\/upload\\F7B30622-FAC8-4767-BA32-BC84E4B70F85.json', 'F7B30622-FAC8-4767-BA32-BC84E4B70F85', '1501210250036');
INSERT INTO `signal_file` VALUES ('82', 'yMatrix.json', 'D:\\Program Files\\apache-tomcat-9.0.0.M21\\webapps\\wtpwebapps\\com.blackandwhite-web\\/upload\\39AF9E10-45F9-49B9-8102-7223A4E7C3D4.json', '39AF9E10-45F9-49B9-8102-7223A4E7C3D4', '1501210362259');
INSERT INTO `signal_file` VALUES ('83', 'yMatrix.json', 'D:\\Program Files\\apache-tomcat-9.0.0.M21\\webapps\\wtpwebapps\\com.blackandwhite-web\\/upload\\C66822EB-3332-41E5-B1F7-2C0975AA1293.json', 'C66822EB-3332-41E5-B1F7-2C0975AA1293', '1501210437881');
INSERT INTO `signal_file` VALUES ('84', 'yMatrix.json', 'D:\\Program Files\\apache-tomcat-9.0.0.M21\\webapps\\wtpwebapps\\com.blackandwhite-web\\/upload\\79E87E2A-6B81-4D58-A4E2-D706A3DF847E.json', '79E87E2A-6B81-4D58-A4E2-D706A3DF847E', '1501223870251');
SET FOREIGN_KEY_CHECKS=1;
