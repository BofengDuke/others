#!/usr/bin/python
#-*- coding:utf-8 -*-

'''
Description: DCT基作为稀疏基，重建算法为OMP算法 ，图像按列进行处理
'''

import  numpy as np
import math,time,json,sys,os
import oss2

ACCESS_KEY_ID = " " # 填写自己的ID
ACCESS_KEY_SECRET = ""
BUCKET = "testblack" # 填写自己的密钥
ENDPOINT = "http://oss-cn-hangzhou.aliyuncs.com"

INPUT= "/home/input";
OUTPUT = "/home/output";


#OMP算法函数
def cs_omp(y,D):    
    L= int(math.floor(1*(y.shape[0])/4))    
    residual=y                  #初始化残差
    _index=np.zeros((D.shape[1]),dtype=int)
    for i in range(D.shape[1]):
        _index[i]= -1
    result=np.zeros((D.shape[1]))
    
    for j in range(L):          #迭代次数
        product=np.fabs(np.dot(D.T,residual))
        pos=np.argmax(product)  #最大投影系数对应的位置        
        _index[j]=pos
        my=np.linalg.pinv(D[:,_index>=0]) #求伪逆   
        a=np.dot(my,y)          #最小二乘  
        residual=y-np.dot(D[:,_index>=0],a)
    result[_index>=0]=a
    return  result

def OMPRestruct(yMatrix,phi):
    """ 重构的接口
    """
    imgsize = phi.shape[1]

    # 重构
    restruct_x = np.zeros((imgsize,imgsize))    # 初始化稀疏系数矩阵    
    for i in range(imgsize):
        column_rec=cs_omp(yMatrix[:,i],phi)     # 利用OMP算法计算稀疏系数
        restruct_x[:,i]=column_rec;  
    
    return restruct_x


def restructDataFromFile(yFileName,phiFileName):
    """ 从文件读取数据并重构
    """
    yMatrixAll = []
    phi= []

    startTime = time.time()
    uuid = sys.argv[1]
    

    # 读取 y 值
    with open(yFileName,"r") as fp:
        _yMatrixAll = json.load(fp)
        maxKey = max(map(int,map(str,_yMatrixAll)))

        for k in range(1,maxKey+1):
            _yMatrix = _yMatrixAll.get(str(k)).strip("\t\n").split("\n")
            yMatrix = []
            for line in _yMatrix:
                line = line.strip("\t").split("\t")
                line = map(float,map(str,line))
                yMatrix.append(line)
            yMatrixAll.append(yMatrix)

    print len(yMatrixAll)

    # 读取 phi 值
    with open(phiFileName,"r") as fp:
        data = json.load(fp)
        _phi = data.get("phi").strip("\t\n").split("\n")

        for line in _phi:
            line = line.strip("\t").split("\t")
            line = map(float,map(str,line))
            phi.append(line)

    # 转为 numpy.ndarray 格式
    yMatrixAll = np.array(yMatrixAll)
    phi = np.array(phi)

    # 分开重构
    resultAll = {}
    key = 1
    for yMatrix in yMatrixAll:
        result = OMPRestruct(yMatrix,phi)
        # print result
        result = [map(str,line) for line in result]
        resultStr = ""
        for line in result:
            tmp = '\t'.join(line)+"\n"
            resultStr += tmp
        resultAll[str(key)] = resultStr
        key += 1

    outputPath = "OMP/output/"+str(uuid)
    output = OUTPUT + "/"+str(uuid)+"/"


    if os.path.exists(output):
        sys.exit(0)
    
    os.makedirs(output)
    jsonObj = json.dumps(resultAll)
    with open(output+"encryptS.json","w") as fp:
        fp.write(jsonObj)

    runTime = time.time() - startTime
    print "run time: " + str(runTime)


if __name__ == '__main__':

    yMatrix = INPUT+"/"+sys.argv[1]+"/yMatrix.json"
    proEncrypt = INPUT+"/"+sys.argv[1]+"/proEncrypt.json"
    
    # yMatrix = "yMatrix.json"
    # proEncrypt ="proEncrypt.json"
    restructDataFromFile(yMatrix,proEncrypt)

