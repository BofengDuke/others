package BlackWhite.CS.ProEncrypt;

import javax.swing.JOptionPane;

import org.apache.mahout.math.Matrix;

import BlackWhite.CS.ImageCS.CSensingHelp;
import BlackWhite.CS.Matrix.MatrixHelper;

public class ProEncrypt {
	
	public static void problemEncrypt(String water, String mk1, String mk2, int signalLength){
		
		int numMeasurements = (int)(signalLength*0.7);  // �������� m
		double [] waterSequence = WaterHelper.getWaterMarkSequence(water, signalLength);
		Matrix detectWaterMatrix = WaterHelper.formWaterMatrix1(waterSequence, signalLength);
		
		int[] sequence = CSensingHelp.getRandomSequence(mk1, 1, mk2, signalLength);// ��ȡ������� rsi
		int seed = CSensingHelp.getSeedBySequence(sequence);	// ��ȡ�������
		// ���ɹ۲����
		Matrix Phi = MatrixHelper.getMeasurements(numMeasurements, signalLength, seed);	
//		System.out.println("�������");
//		MatrixHelper.printMatrix(Phi);
		Matrix csWater = Phi.times(detectWaterMatrix);
		Matrix encrytMatrixM = CSensingHelp.encryptMatrix(sequence);
		Matrix encrytMatrixPhi = Phi.times(encrytMatrixM);
//		MatrixHelper.printMatrix(encrytMatrixM);
		MatrixHelper.writeToFile("./file/water.txt", csWater);
		Matrix outMatrix[] = new Matrix[2];
		outMatrix[0] = csWater;
		outMatrix[1] = encrytMatrixPhi;
		MatrixHelper.writeToJson(outMatrix, "C:/Users/TsengBiao/Desktop/CS_Workshop/file/proEncrypt.json", false);
		
		JOptionPane.showMessageDialog(null,"������浽��"+"CS_Workshop/fileĿ¼��"+"!", "���ɳɹ�",JOptionPane.WARNING_MESSAGE);
		
	}

	
	
	
}
