package BlackWhite.CS.ProEncrypt;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.geom.AffineTransform;
import java.awt.image.AffineTransformOp;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Random;

import javax.imageio.ImageIO;

import org.apache.mahout.math.Matrix;
import org.apache.mahout.math.SparseMatrix;

import BlackWhite.CS.Matrix.MatrixHelper;

public class WaterHelper {
	/**
	 * @param Xi_Yi
	 * @param Wi_Zi
	 * @return ����ˮӡͳ�Ʋ���ֵ
	 */
	public static double[] calcOriginalQorQcs(Matrix Xi_Yi, Matrix Wi_Zi){
		//����������źű�Ϊnά�������ź�
		Matrix signalXi_Yi = MatrixHelper.toSingleColumn(Xi_Yi);
		Matrix signalWi_Zi = MatrixHelper.toSingleColumn(Wi_Zi);
		
		if(signalWi_Zi.rowSize() != signalXi_Yi.rowSize())
			return null;
		
		int count = signalXi_Yi.rowSize();//�źŹ�ģ
		double mc = 0;
		double vc = 0;
		
		//����Mc/Mc'
		double Xi_YiTimesWi_Zi[] = new double[count];
		for(int i = 0; i < count; i++){
			Xi_YiTimesWi_Zi[i] = signalXi_Yi.get(i, 0)*signalWi_Zi.get(i, 0);
			mc = mc + Xi_YiTimesWi_Zi[i];
		}
		
		mc = mc/count;
		
		//����Vc/Vc'
		for(int j = 0; j < count; j++){
			double temp = (Xi_YiTimesWi_Zi[j] - mc)*(Xi_YiTimesWi_Zi[j] - mc);
			vc = vc + temp;
		}
		
		vc = Math.sqrt(vc / (count-1));
		//����q/qcs
		double q = Math.sqrt(count)*mc/vc;
		double result[] = {mc,vc,q};
		return result;
	}
	
	/**
	 * ����CS���ˮӡ
	 * @param waterDetectMatrix
	 * @param Phi
	 * @return CS domain watermarks
	 */
	public static Matrix getCsWater(Matrix waterDetectMatrix, Matrix Phi){
		if(Phi.columnSize() != waterDetectMatrix.rowSize() )
			return null;
		return Phi.times(waterDetectMatrix);
	}
	
	/**
	 * ���ַ�������ת��Ϊ01����
	 * @param str
	 * @return bit stream of str
	 */
	private static String StrToBinstr(String str) {
        char[] strChar=str.toCharArray();
        String result="";
        for(int i=0;i<strChar.length;i++){
            result +=Integer.toBinaryString(strChar[i]);
        }
        return result;
    }

	/**
	 * ����ˮӡ��Ϣ���û��������Կ���͵�ˮӡ�ַ���������1/-1���е��ַ���
	 * @param waterMark
	 * @param sizeOfImage
	 * @return waterMarkSequence
	 */
	public static double[] getWaterMarkSequence(String waterMark, int sizeOfImage){
		String bitWater = StrToBinstr(waterMark);
		char[] bitWaterArr = bitWater.toCharArray();
		
		int finalSizeOfWaterSequence = (sizeOfImage)*(sizeOfImage);//����ˮӡ������ԭͼ��ģһ��
		int lenOfWaterArr = bitWaterArr.length;//ȡˮӡ���г���
		double[] bitWaterFinal = new double[finalSizeOfWaterSequence];
		
		if(lenOfWaterArr > finalSizeOfWaterSequence){//ˮӡ����С������Ҫ�����д�С
			
			for(int i = 0; i < finalSizeOfWaterSequence; i++){
				if(bitWaterArr[i] =='0')
					bitWaterFinal[i] = -1;
				else
					bitWaterFinal[i] = 1;
			}
		}
		else{
			//�������ˮӡ��Ϣ�ظ�����Ϊ�涨���ȵ�ˮӡ�ź�
			int times = finalSizeOfWaterSequence/lenOfWaterArr;
			String bitWaterTemp =  "";
			for(int j = 0; j < times; j++){
				bitWaterTemp += bitWater;
			}
			
			int tempSizeOfbitWaterTemp = bitWaterTemp.length();
			for(int k = 0; k < finalSizeOfWaterSequence - tempSizeOfbitWaterTemp; k++){
				bitWaterTemp = bitWaterTemp + bitWaterArr[k];
			}
			
			char[] bitWaterTempArr = bitWaterTemp.toCharArray();
			for(int i = 0; i < finalSizeOfWaterSequence; i++){
				if(bitWaterTempArr[i] =='0')
					bitWaterFinal[i] = -1;
				else
					bitWaterFinal[i] = 1;
			}	
		}
		return bitWaterFinal;
	}
	
	/**
	 * ����ˮӡ����
	 * @param waterMarkSequence
	 * @param sizeOfImage
	 * @return waterMatrix
	 */
	public static Matrix formWaterMatrix1(double[] waterMarkSequence, int sizeOfImage){

		int nWater = sizeOfImage;
		double[][] watersMatrix = new double[nWater][nWater];
		for(int i = 0; i< nWater/2; i++){
			for(int j=0; j< nWater/2; j++){
				watersMatrix[i][j+nWater/2] = waterMarkSequence[i*nWater/2+j];
			}
		}
		return MatrixHelper.doubleToMatrix(watersMatrix);
	}
	
	
	public static Matrix formWaterMatrix(int imgWidth) {
		Matrix resultWaterMatrix = new SparseMatrix(imgWidth,imgWidth);
		for(int i = 0; i < imgWidth; i++){
			for(int j = 0; j < imgWidth; j++){
				Random ranWateri = new Random();
				int wi = ranWateri.nextInt(2);
				if(wi==1){
					resultWaterMatrix.set(i, j, 1);
				}
				else
					resultWaterMatrix.set(i, j, -1);	
			}
		}
		return resultWaterMatrix;
	}  

	/**
	 * ��ϡ���źŽ���ˮӡǶ��
	 * @param sparaseSignal
	 * @param waterMark
	 * @param strength
	 * @return watered sparase signal
	 */
	public static double[][] getSignalWithWaterMark(double[][]sparaseSignal,double[][] waterMark,int strength){

		double[][] resultSparaseWateredSignal = new double[sparaseSignal.length][sparaseSignal.length];
		for(int i = 0; i < sparaseSignal.length; i++){
			for(int j = 0; j < sparaseSignal.length; j++){
				resultSparaseWateredSignal[i][j] = sparaseSignal[i][j] + waterMark[i][j]*strength;
			}
		}
		return resultSparaseWateredSignal;
	}
	
	  /**
	   * ����ͼ��ָ����С
	 * @param srcImageFile
	 * @param result
	 * @param height
	 * @param width
	 * @param bb
	 */
	public final static void scale(String srcImageFile, String result, int height, int width, boolean bb) {  
	        try {  
	            double ratio = 0.0; // ���ű���  
	            File f = new File(srcImageFile);  
	            BufferedImage bi = ImageIO.read(f);  
	            Image itemp = bi.getScaledInstance(width, height, Image.SCALE_SMOOTH);  
	            // �������  
	            if ((bi.getHeight() > height) || (bi.getWidth() > width)) {  
	                if (bi.getHeight() > bi.getWidth()) {  
	                    ratio = (new Integer(height)).doubleValue()  
	                            / bi.getHeight();  
	                } else {  
	                    ratio = (new Integer(width)).doubleValue() / bi.getWidth();  
	                }  
	                AffineTransformOp op = new AffineTransformOp(AffineTransform  
	                        .getScaleInstance(ratio, ratio), null);  
	                itemp = op.filter(bi, null);  
	            }  
	            if (bb) {//����  
	                BufferedImage image = new BufferedImage(width, height,  
	                        BufferedImage.TYPE_INT_RGB);  
	                Graphics2D g = image.createGraphics();  
	                g.setColor(Color.white);  
	                g.fillRect(0, 0, width, height);  
	                if (width == itemp.getWidth(null))  
	                    g.drawImage(itemp, 0, (height - itemp.getHeight(null)) / 2,  
	                            itemp.getWidth(null), itemp.getHeight(null),  
	                            Color.white, null);  
	                else  
	                    g.drawImage(itemp, (width - itemp.getWidth(null)) / 2, 0,  
	                            itemp.getWidth(null), itemp.getHeight(null),  
	                            Color.white, null);  
	                g.dispose();  
	                itemp = image;  
	            }  
	            ImageIO.write((BufferedImage) itemp, "JPEG", new File(result));  
	        } catch (IOException e) {  
	            e.printStackTrace();  
	        }  
	    }
}
