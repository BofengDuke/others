package BlackWhite.CS.ImageCS;

import org.apache.mahout.math.Matrix;
import BlackWhite.CS.Matrix.MatrixHelper;
import BlackWhite.CS.ProEncrypt.WaterHelper;

public class CompressiveSensing {
	private final static int WATER_STRENTH = 15;
	/**
	 * @param imageI
	 * @param waters
	 * @param mainKey1
	 * @param mainKey2
	 * @param ifWater
	 * @return �ֿ�ͼ��Ĳ���ֵyi
	 */
	public static Matrix compressing(double[][] imageI,String waters, String mainKey1,String mainKey2,boolean ifWater) {
		
		double[][]sparseSignal = getSparseSignals(imageI);
		double[][] handleSignal = sparseSignal;

		if(ifWater){
			System.out.println("ifWater"+ifWater);
			long tWaterIn1 = System.currentTimeMillis();
			//��ȡǶ��ˮӡ���ź�X'
			int strenth = WATER_STRENTH;
			double [] waterSequence = WaterHelper.getWaterMarkSequence(waters, imageI.length/2);
			Matrix detectWaterMatrix = WaterHelper.formWaterMatrix1(waterSequence, imageI.length);
			handleSignal = WaterHelper.getSignalWithWaterMark(sparseSignal,MatrixHelper.matrixToDouble(detectWaterMatrix),strenth);
			long tWaterIn2 = System.currentTimeMillis();
			System.out.println("ˮӡǶ�룺"+(tWaterIn2-tWaterIn1)+"ms");
		}
		
		// ��ʼ��ֵ
		int signalLength = 	handleSignal.length;// �źų���  N
		int numMeasurements = (int)(signalLength*0.7);  // �������� m
		
//		System.out.println("wentimk1:"+mainKey1+"mk2:"+mainKey2);
		int[] sequence = CSensingHelp.getRandomSequence(mainKey1, 1, mainKey2, signalLength);// ��ȡ������� rsi
		int seed = CSensingHelp.getSeedBySequence(sequence);	// ��ȡ�������
		// ���ɹ۲����
		Matrix Phi = MatrixHelper.getMeasurements(numMeasurements, signalLength, seed);	
//		MatrixHelper.printMatrix(Phi);
		Matrix yMatrix = Phi.times(MatrixHelper.doubleToMatrix(handleSignal));
		
		return yMatrix;
	}
	
	/**
	 * @param originalSignal
	 * @return ϡ���ź�S
	 */
	@SuppressWarnings("unused")
	private static double[][] getSparseSignals1(double[][] originalSignal) {		
		Jama.Matrix originalMatrix = new Jama.Matrix(originalSignal);
		double[][] DCTBase = ImageDCT.DCT_Base(originalSignal.length);
		Jama.Matrix DCTBaseMatrix = new Jama.Matrix(DCTBase);
	
		Jama.Matrix InverseDCTBase = DCTBaseMatrix.inverse();
		
		return MatrixHelper.JamaMatrixToDouble(InverseDCTBase.times(originalMatrix));

	}
	
	
	/**
	 * ��ԭʼ�źŽ���DCT�任�������ˣ���ȡ�õ�ϡ���ź�
	 * @param originalSignal   ԭʼ�ź�
	 * @return ���� N*N ��ϡ����� S
	 */
	private static double[][] getSparseSignals(double[][] originalSignal) {		
		
		// ����dDCT�任
		double[][] dctResult = null;
		try{
			dctResult = ImageDCT.dct2(originalSignal,0);
		}catch(Exception e){
			e.printStackTrace();
		}
		
		Matrix resultMatrix = MatrixHelper.doubleToMatrix(dctResult);

		return MatrixHelper.matrixToDouble(resultMatrix);

	}
	

	
	


}

