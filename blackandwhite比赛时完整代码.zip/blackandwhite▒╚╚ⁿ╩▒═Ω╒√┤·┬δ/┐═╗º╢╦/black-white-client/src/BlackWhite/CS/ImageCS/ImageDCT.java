package BlackWhite.CS.ImageCS;

import java.text.DecimalFormat;

import org.apache.mahout.math.Matrix;
import org.apache.mahout.math.SparseMatrix;

import BlackWhite.CS.Matrix.MatrixHelper;
public class ImageDCT {
	/*
	 * Method that permit to print a Matrix for debug purpose
	 */
	protected static void printMatrix(double[][] z) {
		int n = z.length;
		int m = z[0].length;

		System.out.print("[");
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				System.out.print(z[i][j]);
				if (j != m - 1)
					System.out.print(" ");
			}
			if (i != n - 1)
				System.out.println();
		}
		System.out.println("]");
	}

	/*
	 * Method that calculate dct2 in two dimensions, first calculate dct in row
	 * and after calculate dct in column
	 */
	protected static double[][] dct2(double[][] z, double offset) throws Exception {
		if (z.length == 0)
			throw new Exception("z empty");

		if (z[0].length == 0)
			throw new Exception("z row empty");

		int n = z.length;
		int m = z[0].length;
		double[][] c = new double[n][m];
		double[][] c2 = new double[n][m];
		double alfa;
		double sum;

		DecimalFormat dFormat = new DecimalFormat("#.####");

		for (int k = 0; k < n; k++) {
			for (int l = 0; l < m; l++) {
				sum = 0;
				for (int i = 0; i < n; i++) {
					sum += (z[i][l] + offset) * Math.cos((Math.PI * (2. * i + 1.) * k) / (2. * n));
				}
				alfa = k == 0 ? 1. / Math.sqrt(n) : Math.sqrt(2. / n);
				c[k][l] = alfa * sum;
			}
		}

		for (int l = 0; l < m; l++) {
			for (int k = 0; k < n; k++) {
				sum = 0;
				for (int j = 0; j < m; j++) {
					sum += c[k][j] * Math.cos((Math.PI * (2. * j + 1.) * l) / (2. * m));
				}
				alfa = l == 0 ? 1. / Math.sqrt(m) : Math.sqrt(2. / m);
				c2[k][l] = Double.valueOf(dFormat.format(alfa * sum));
			}
		}

		return c2;
	}

	/*
	 * Method that calculate idct2 in two dimensions, first calculate idct in
	 * row and after calculate idct in column
	 */
	public static double[][] idct2(double[][] z, double offset) throws Exception {
		if (z.length == 0)
			throw new Exception("z empty");

		if (z[0].length == 0)
			throw new Exception("z row empty");

		int n = z.length;
		int m = z[0].length;
		double[][] c = new double[n][m];
		double[][] c2 = new double[n][m];
		double alfa;
		@SuppressWarnings("unused")
		DecimalFormat dFormat = new DecimalFormat("#.####");

		for (int k = 0; k < n; k++) {
			for (int l = 0; l < m; l++) {
				c[k][l] = 0;
				for (int i = 0; i < n; i++) {
					alfa = i == 0 ? 1. / Math.sqrt(n) : Math.sqrt(2. / n);
					c[k][l] += alfa * z[i][l] * Math.cos((Math.PI * (2 * k + 1) * i) / (2 * n));
				}
			}
		}

		for (int l = 0; l < m; l++) {
			for (int k = 0; k < n; k++) {
				c2[k][l] = 0;
				for (int j = 0; j < m; j++) {
					alfa = j == 0 ? 1. / Math.sqrt(m) : Math.sqrt(2. / m);
					c2[k][l] += alfa * c[k][j] * Math.cos((Math.PI * (2 * l + 1) * j) / (2 * m));
				}
				c2[k][l] += offset;
				c2[k][l] = (int)(c2[k][l]);
			}
		}

		return c2;
	}
	
	/**
	 * @param z
	 * @param threshold
	 * @return 
	 * @throws Exception
	 */
	public static double[][] filter(double[][] z, double threshold) throws Exception {

		if (z.length == 0)
			throw new Exception("z empty");

		if (z[0].length == 0)
			throw new Exception("z row empty");

		int n = z.length;
		int m = z[0].length;

		int i = ((int) Math.rint(n * threshold));
		int j = ((int) Math.rint(m * threshold));


		for (int x = i; x < n; x++) {
			for (int y = j; y < m; y++) {
				z[x][y] = 0.0;
			}
		}
		return z;
	}
	
	/**
	 * ����DCTϡ���
	 * @param len
	 * @return
	 */
	public static double[][] DCT_Base(int len){
		Matrix resultMatrix = new SparseMatrix(len,len);
		resultMatrix = MatrixHelper.fillWithZeros(resultMatrix);
		double[] v = new double[len];
		for(int i=0; i<len; i++)
			v[i]= i;
		
		for(int j=0; j<len; j++){
			double[]dct_1d = new double[len];
			double sumOfDct_1d = 0;
			for(int k=0; k<len; k++){
				double temp = Math.cos(v[k]*(j*Math.PI/len));
				dct_1d[k] = temp;
				sumOfDct_1d += temp;
			}
			
			double meanofDct_1d = sumOfDct_1d/len;
			//����Dct_1d
			if(j>0){
				for(int m=0; m<len; m++){
					dct_1d[m] -= meanofDct_1d;
				}
			}
			
			double norm =  calcNorm(dct_1d);
			Matrix dct_1dMatrix = new SparseMatrix(dct_1d.length,1);
			for(int n=0; n<dct_1d.length; n++){
				dct_1d[n] = dct_1d[n]/norm;
				dct_1dMatrix.set(n, 0, dct_1d[n]);
			}
			
			MatrixHelper.fillColumn(resultMatrix, dct_1dMatrix, j);
				
		}
		return MatrixHelper.matrixToDouble(resultMatrix);	
	}
	
	/**
	 * ������Ķ�����
	 * @param normArr
	 * @return
	 */
	public static double calcNorm(double[]normArr){
		double powSum = 0;
		double resultNorm = 0;
		for(int i=0; i<normArr.length; i++){
			powSum += Math.pow(normArr[i], 2);
		}
		resultNorm = Math.sqrt(powSum);
		return resultNorm;
		
	}
}
