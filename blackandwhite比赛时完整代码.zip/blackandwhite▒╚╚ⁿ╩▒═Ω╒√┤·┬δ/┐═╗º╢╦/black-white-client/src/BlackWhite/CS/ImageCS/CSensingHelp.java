package BlackWhite.CS.ImageCS;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

import javax.imageio.ImageIO;
import javax.swing.JOptionPane;

import org.apache.mahout.math.Matrix;
import org.apache.mahout.math.SparseMatrix;

import BlackWhite.CS.ImageDecrypt.ImageDecryption;
import BlackWhite.CS.Matrix.MatrixHelper;

public class CSensingHelp {

	public static final int DEFAULT_ITH_IMAGE = 1;
	public static final int DEFAULT_BLOCKSIZE = 64;
	public static  boolean DEFAULT_IF_WATER = false;
	
	/**
	 * sdi <- F1(mk1,i)
	 *@param: mk1(MasterKey1)
	 *@param: i(ith image)
	 *@retrun a int random seed
	 */
	private static int genRandomSeed(String MasterKey1, int ith){
		int randomSeed = 0;
		char [] masterKey = MasterKey1.toCharArray();
		int tempSeed = 0;
		
		for(int i = 0; i < masterKey.length; i++){
			tempSeed += (int)masterKey[i];
		}
		
		Random rSeed = new Random(tempSeed+ith);
		randomSeed = rSeed.nextInt(tempSeed+ith);
		
		return randomSeed;
	}
	
	/**
	 * rsi <- F2(mk2,sdi)
	 *@param: mk2(MasterKey2)
	 *@param: sdi(retrun by F1(mk1,i))
	 *@param: n(scale of image)
	 *@return a sequence contains n entries
	 * */
	private static int[] genRandomSequence(String MasterKey2, int randomSeed, int n){
		int randomSequence[] = new int[n];
		char [] masterKey = MasterKey2.toCharArray();
		int tempSeed = 0;
		for(int i = 0; i < masterKey.length; i++){
			tempSeed = tempSeed += (int)masterKey[i];
		}
		int finalSeed = tempSeed ^ randomSeed;
		if(finalSeed == 0)
			finalSeed = tempSeed;
		Random radomSequenceDigist = new Random(finalSeed);
		for(int j = 0; j < n; j++){
			randomSequence[j] = radomSequenceDigist.nextInt(finalSeed);
		}
		return randomSequence;
	}

	/**
	 * Generate PI function for Permutation Matrix P
	 *@param: x(2n entries)
	 *@return PI sequence contains 2n entries
	 * */
	private static int[] genPiX(int []x){
		int PiX[] = new int[x.length];
		for(int i = 0; i < x.length; i++){
			x[i] = i;
		}
		
        ArrayList<Integer> list = new ArrayList<Integer>();  
        for(int i = 0; i < x.length; i++){  
            list.add(x[i]);  
        }  
        Collections.shuffle(list); //Pi(x)
        
        for(int j = 0; j < x.length; j++){
        	PiX[j] = list.get(j);
        }
        
        return PiX;
	}
	
	/**
	 * GenPermutationMatrix P
	 * @param: entries[] contains 2n entries
	 * @return  a 2n x 2n permutaion matrix P
	 * */
	@SuppressWarnings("unused")
	private static Matrix genPermutationMatrix(int[]entries){
		int twiceN = entries.length;
		if(twiceN%2 !=0)
			return null;
		Matrix permutaionMatrix = new SparseMatrix(twiceN,twiceN);
		permutaionMatrix =MatrixHelper.fillWithZeros(permutaionMatrix);
		int x[] = new int[twiceN];
		int PiX[] = genPiX(x);//Pi(x)Function
		for (int row = 0; row < permutaionMatrix.rowSize(); row++) {
			for (int column = 0; column < permutaionMatrix.columnSize(); column++) {
				if(row == PiX[column])
					permutaionMatrix.set(row, column, 1); //set cell's value to 1
			}
		}
		
		return permutaionMatrix;
	}
	
	
	/**
	 *  GenGiagnoalMatrix D
	 * @param: entries[] contains n entries
	 * @return  a n x n diagnoal matrix D
	 * */
	private static Matrix genDiagonalMatrixD(int[]entries){
		int twiceN = entries.length;
		if(twiceN%2 !=0)
			return null;
		Matrix diagonalMatrix = new SparseMatrix(twiceN,twiceN);
		diagonalMatrix =MatrixHelper.fillWithZeros(diagonalMatrix);
		
		for (int index = 0; index < twiceN; index++) {
			diagonalMatrix.set(index, index, entries[index]);
		}
		
		return diagonalMatrix;
	}
	
	/**
	 * ͨ������Կ key1 �͵�i��ͼƬ ith, ����������� seed�� 
	 * ��ͨ�� ����Կkey2��ͼƬ���ȣ��Լ�seed ���� �������
	 * @param key1 ����Կ key1
	 * @param ith  �� i ��ͼƬ
	 * @param key2 ����Կ key2
	 * @param imageWidth  ͼƬ�Ŀ�
	 * @return ����Ϊn�������������
	 */
	public static int[] getRandomSequence(String key1,int ith,String key2,int imageWidth){
		int seed = CSensingHelp.genRandomSeed(key1, ith);
		int[] randomSequuence = CSensingHelp.genRandomSequence(key2,seed,imageWidth);
		
		return randomSequuence;
	}
	
	/**
	 * ���ɼ��ܾ���
	 * @param mMatrix
	 * @param sequence
	 * @return
	 */
	public static Matrix encryptMatrix(int[] sequence) {
		Matrix matrixD = genDiagonalMatrixD(sequence);
		return matrixD;
	}

	/**
	 * ��ͼ��ֿ����ѹ����֪�������зֿ�Ĳ���ֵyд��Json�ļ���
	 * @param testImagePath
	 * @param mk1
	 * @param mk2
	 * @param water
	 * @throws IOException 
	 */
	public static void csImageBlock(String testImagePath,String mk1, String mk2, String water) throws IOException{

		// ��ȡԭʼ�ź�X
		double[][] originalSignal = getImageGrayPixel(testImagePath);
		
/*==========================================д��ͼ�����===========================================*/
		ImageIO.write(ImageDecryption.ArrayInt2Image(originalSignal), "jpg", new File(ImageDecryption.WRITE_IMAGE+"source"+".jpg"));
//		System.out.println("ԭʼ�źţ�");
//		MatrixHelper.printMatrix(MatrixHelper.doubleToMatrix(originalSignal));
		
		int imgSizeN = originalSignal.length;//��ȡͼ���ģ
		int blockSize = DEFAULT_BLOCKSIZE;//�ֿ��С
		int blocks = (imgSizeN/blockSize)*(imgSizeN/blockSize);//�ֿ���Ŀ
		int blockImgs = imgSizeN/blockSize;//ÿ������ͼ����	
		// ��������Y
		Matrix csYMatrix [] = new Matrix[blocks];
		
		long tBlockCS1 = System.currentTimeMillis();
		//��ԭʼͼ����зֿ飬����ÿһ�����CS
		for(int i = 0; i < blockImgs; i++){
			for(int j = 0; j < blockImgs; j++){
				
				int x = i*blockSize;
				int y = j*blockSize;
				double [][] tempImg = new double[blockSize][blockSize];
				for(int m=0; m<blockSize; m++){
					for(int n=0; n<blockSize; n++){
						tempImg[m][n] = originalSignal[m+x][n+y];
					}
				}
				
//				System.out.println("�ֿ��źţ�"+(i*blockImgs+j));
//				MatrixHelper.printMatrix(MatrixHelper.doubleToMatrix(tempImg));
				if((i*blockImgs+j)==1)
					DEFAULT_IF_WATER = true;
				else if(blocks==1)
					DEFAULT_IF_WATER = true;
				else
					DEFAULT_IF_WATER = false;
				Matrix tempResult = CompressiveSensing.compressing(tempImg, water,mk1, mk2,DEFAULT_IF_WATER);
				
				csYMatrix[i*blockImgs+j] = tempResult;
			}
		}
		long tBlockCS2 = System.currentTimeMillis();
		System.out.println("�ֿ�CS��"+(tBlockCS2-tBlockCS1)+"ms");
		JOptionPane.showMessageDialog(null,"������浽��"+"CS_Workshop/fileĿ¼��"+ "!", "���ܳɹ�",JOptionPane.WARNING_MESSAGE);
		long writeJsonY1 = System.currentTimeMillis();
		MatrixHelper.writeToJson(csYMatrix, "C:/Users/TsengBiao/Desktop/CS_Workshop/file/yMatrix.json",true);
		long writeJsonY2 = System.currentTimeMillis();
		System.out.println("���ɲ���ֵY����"+(writeJsonY2-writeJsonY1)+"ms");
	}
	
	/**
	 * ��ȡͼƬ8λ�Ҷ�����
	 * @param imagePath
	 * @return ͼƬÿһ�����ĻҶ�����
	 */
	private static double[][] getImageGrayPixel(String imagePath){
		BufferedImage src = null;
		try{
			src = ImageIO.read(new File(imagePath));
		}catch(IOException e){
			e.printStackTrace();
		}
		
		double[][] srcPixel = new double[src.getWidth()][src.getHeight()];
		int pixel = 0;
		int R,G,B;
		for(int x=0;x<src.getWidth();x++){
			for(int y=0;y<src.getHeight();y++){
				pixel = src.getRGB(x, y);
				R = (pixel & 0xff0000) >> 16;
				G = (pixel & 0x00ff00) >> 8;
				B = (pixel & 0x0000ff);
				pixel = (int)(0.2989 * R + 0.5870 * G + 0.1140 * B);
				srcPixel[x][y] = pixel;
			}
		}
		return srcPixel;
	}
	
	/**
	 * ͨ������һ���������飬��ȡ��һ���������
	 * @param seeds
	 * @return
	 */
	public static int getSeedBySequence(int[] seeds) {
		int seed = 0;
		for(int i=0;i<seeds.length;i++){
			seed += seeds[i];
		}
		Random random = new Random(seed);
		return random.nextInt(99999999) + 10000000;
	}
	
	
}
