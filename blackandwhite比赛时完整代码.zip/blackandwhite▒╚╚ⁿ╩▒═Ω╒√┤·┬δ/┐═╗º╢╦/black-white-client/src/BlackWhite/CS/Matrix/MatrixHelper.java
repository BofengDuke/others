package BlackWhite.CS.Matrix;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Random;

import org.apache.mahout.math.Matrix;
import org.apache.mahout.math.SparseMatrix;

import net.sf.json.JSONObject;

public class MatrixHelper {
	
	/**
	 * ��double��ά����תΪMatrix����
	 * @param datas  ��ά����
	 * @return
	 */
	public static Matrix doubleToMatrix(double[][] datas){
		Matrix matrix = new SparseMatrix(datas.length, datas[0].length);
		for(int x=0;x<datas.length;x++){
			for(int y=0;y<datas[0].length;y++){
				matrix.set(x, y,datas[x][y]);
			}
		}
		return matrix;
	}
	/**
	 * ������ת��Ϊdouble[][]��ά����
	 * @param datas
	 * @return double[][] of Matrix datas
	 */
	public static double[][] matrixToDouble(Matrix datas){
		double[][]result = new double[datas.rowSize()][datas.columnSize()];
		for(int x=0;x<datas.rowSize();x++){
			for(int y=0;y<datas.columnSize();y++){
				result[x][y] = datas.get(x, y);
			}
		}
		
		return result;
	}
	
	/**
	 * ��Jama����ת��Ϊdouble[][]��ά����
	 * @param datas
	 * @return
	 */
	public static double[][] JamaMatrixToDouble(Jama.Matrix datas){
		double[][]result = new double[datas.getRowDimension()][datas.getColumnDimension()];
		for(int x=0;x<datas.getRowDimension();x++){
			for(int y=0;y<datas.getColumnDimension();y++){
				result[x][y] = datas.get(x, y);
			}
		}
		
		return result;
	}

	/**
	 * ��ʼ������Ԫ��ȫ����0
	 * Does the same thing as MATLAB's zeros(m, n) function.
	 * 
	 * @param zeroMatrix - the matrix that should be filled with zeros
	 * @return the matrix with all zero values
	 */
	public static Matrix fillWithZeros(Matrix zeroMatrix){

		for (int row = 0; row < zeroMatrix.rowSize(); row++) {
			for (int column = 0; column < zeroMatrix.columnSize(); column++) {
				zeroMatrix.set(row, column, 0); //set cell's value to zero
			}
		}

		return zeroMatrix;
	}

	/**
	 * 
	 * @param randomMatrix - this matrix with be filled with Gaussian random numbers
	 * @param seed ������ӣ�����ʹ���ɵĸ�˹�������α�����
	 * @return a matrix containing pseudorandom values drawn from the 
	 * standard normal distribution. 
	 */
	public static Matrix randN(Matrix randomMatrix,int seed){

		double randNum = 0;
		Random rand = new Random(seed);

		for (int row = 0; row < randomMatrix.rowSize(); row++) {
			for (int column = 0; column < randomMatrix.columnSize(); column++) {
				//get a Gaussian random number with mean 0 and standard deviation 1
				randNum = rand.nextGaussian();
				randomMatrix.set(row, column, randNum);
			}
		}

		return randomMatrix;
	}
	
	/**
	 * ���ɲ�������Phi
	 * 
	 * @param numMeasurements ��������  M 
	 * @param signalLength    �źų��� N
	 * @return a matrix to be used for measurements
	 */
	public static Matrix getMeasurements(int numMeasurements,int signalLength,int seed){

		Matrix gaussDistMatrix = new SparseMatrix(numMeasurements, signalLength);

		gaussDistMatrix = MatrixHelper.randN(gaussDistMatrix,seed);
		double x = (1 / Math.sqrt(numMeasurements));

		return gaussDistMatrix.times(x);
	}
	
	
	/**
	 * ��ȡ����A�;���B��˵Ľ��������һ������
	 * @param matrixA
	 * @param matrixB
	 * @return
	 */
	public static Matrix getMatrixTimes(Matrix matrixA ,Matrix matrixB ){
		if(matrixA.columnSize() != matrixB.rowSize())
			return null;
		
		Matrix resultMatrix = new SparseMatrix(matrixA.rowSize(), matrixB.columnSize());
		double tmp = 0;
		for(int rowb =0;rowb<matrixB.columnSize();rowb++){
			for(int rowa=0;rowa<matrixA.rowSize();rowa++){
				tmp = 0;
				for(int col=0;col<matrixA.columnSize();col++){
					tmp += matrixA.get(rowa, col) * matrixB.get(col, rowb);
				}
				resultMatrix.set(rowa, rowb,tmp);
			}
		}

		return resultMatrix;
	}

	/**
	 * ������ƽ���Ϳ���--��L2����
	 * 
	 * @param mtrx
	 * @return a value determined by squaring each value in the parameter matrix, adding 
	 * those values together, then taking the square root of that sum.
	 */
	public static double norm(Matrix mtrx){

		double sum = 0;
		for(int i = 0; i < mtrx.rowSize(); i++){
			for(int j = 0; j < mtrx.columnSize(); j++){
				sum += Math.pow(mtrx.get(i, j), 2);
			}
		}
		return Math.sqrt(sum);
	}

	/**
	 * ���finalMatrix��colNum��ΪcurrentMatrix
	 * 
	 * @param finalMatrix - a column in this matrix will be filled with values from currentMatrix
	 * @param currentMatrix - values from the first column of this matrix are retrieved and then set in 
	 * the given column of finalMatrix.
	 * @param colNum - the column in finalMatrix that should be filled
	 * @return the new matrix with the modified column
	 */
	public static Matrix fillColumn(Matrix finalMatrix, Matrix currentMatrix, int colNum){

		for(int row = 0; row < currentMatrix.rowSize(); row++){
			finalMatrix.set(row, colNum, currentMatrix.get(row,  0));
		}

		return finalMatrix;
	}

	/**
	 * ��ȡ������ض���
	 * 
	 * @param mtrx - retrieve the column from this matrix
	 * @param columnNum - the column number to retrieve
	 * @return the column vector
	 */
	public static Matrix getColumn(Matrix mtrx, int columnNum){

		Matrix tempMatrix = new SparseMatrix(mtrx.rowSize(), 1);
		double cellNumber;
		int column = columnNum;
		for(int row = 0; row < mtrx.rowSize(); row++){
			cellNumber = mtrx.get(row, column);
			tempMatrix.set(row, 0, cellNumber);
		}
		return tempMatrix;
	}

	/**
	 * ��ӡ����
	 * Print out the entire matrix.
	 * 
	 * @param signalMatrix
	 */
	public static void printMatrix(Matrix signalMatrix){

		//get the dimensions of the matrix
		int numRows = signalMatrix.rowSize();
		int numColumns = signalMatrix.columnSize();

		//loop through each cell in the matrix and print its value
		for (int row = 0; row < numRows; row++) {
			System.out.print("ROW " + (row+1) + " = ");
			for (int column = 0; column < numColumns; column++) {
				System.out.print(signalMatrix.get(row,column) + " "); // bounds check
			}
			System.out.println();
		}
		System.out.println();
	}
	
	/**���ո�ʽ�������
	 * @param matrix
	 */
	public static void printMatrixFormate(Matrix matrix) {
		int n = matrix.rowSize();
		int m = matrix.columnSize();

		System.out.print("[");
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				System.out.print(matrix.get(i, j));
				if (j != m - 1)
					System.out.print(" ");
			}
			if (i != n - 1)
				System.out.println();
		}
		System.out.println("]");
	}

	/**
	 * ����������д��json�ļ�
	 * @param signal
	 * @param fileName
	 */
	public static void writeToJson(Matrix signal[], String fileName, boolean isY){	
		JSONObject jsonObject = new JSONObject(); 
		for(int i=0; i<signal.length;i++){
//			MatrixHelper.printMatrix(signal[i]);
			String lineString = "";
			for(int j=0; j<signal[i].rowSize();j++){
				for(int k=0; k<signal[i].columnSize();k++){
					lineString = lineString + Double.toString(signal[i].get(j, k))+"\t";
				}	
				lineString += "\n";
			}
			String key = Integer.toString(i+1);
			if(!isY && i==0)
				key = "watermark";
			if(!isY && i==1)
				key = "phi";
			jsonObject.put(key, lineString);
		}
		try {
			writeFile(fileName, jsonObject.toString());
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * �����д�ļ�
	 * @param filePath
	 * @param sets
	 * @throws IOException
	 */
	public static void writeFile(String filePath, String sets) throws IOException {  
	    FileWriter fw = new FileWriter(filePath);  
	    PrintWriter out = new PrintWriter(fw);  
	    out.write(sets);  
	    out.println();  
	    fw.close();  
	    out.close();  
	}

	/**
	 * ����������д���ļ�
	 * 
	 * @param fileName - name of file that the matrix will be written to
	 * @param signalMatrix - the matrix that will be added to the file
	 */
	public static void writeToFile(String fileName, Matrix signalMatrix){

		try {

			File file = new File(fileName);
			
			if(!file.exists()){
				file.createNewFile();
			}
			FileWriter fw = new FileWriter(file);
			BufferedWriter bw = new BufferedWriter(fw);

			//get the dimensions of the matrix
			int numRows = signalMatrix.rowSize();
			int numColumns = signalMatrix.columnSize();
			System.out.println(numRows+"|"+numColumns);
			//loop through each cell in the matrix and write its value
			for (int row = 0; row < numRows; row++) {
				for (int column = 0; column < numColumns; column++) {
					bw.write(signalMatrix.get(row,column) + " "); 
				}
				bw.newLine();
			}
			bw.newLine();
			bw.close();
			fw.close();

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * ������תΪһ�� 
	 * This basically works by stacking each subsequent column under the previous one
	 * until there is only a single column.
	 * Similar to the x = x(:) operation in Matlab.
	 * 
	 * @param mtrx - the matrix that will be transformed into a single column vector
	 * @return the column vector
	 */
	public static Matrix toSingleColumn(Matrix mtrx){

		//create single column matrix with correct number of rows
		int numRows = mtrx.columnSize() * mtrx.rowSize();
		Matrix singleColumnMatrix = new SparseMatrix(numRows, 1);

		int rowCount = 0;
		double cellValue = 0;
		for (int column = 0; column < mtrx.columnSize(); column++) {
			for (int row = 0; row < mtrx.rowSize(); row++) {
				cellValue = mtrx.get(row, column);
				singleColumnMatrix.set(rowCount, 0, cellValue);
				rowCount++;
			}
		}

		return singleColumnMatrix;

	}
	
	/**
	 * �������
	 * @param A 
	 * @param B
	 * @return A+B
	 */
	public static Matrix addMatrix(Matrix A, Matrix B){
		int rowNumA = A.rowSize();
		int rowNumB = B.rowSize();
		int colNumA = A.columnSize();
		int colNumB = B.columnSize();
		if(rowNumA != rowNumB || colNumA != colNumB){
			return null;
		}
		Matrix C = new SparseMatrix(rowNumA, colNumA);
		for(int i = 0; i < rowNumA; i++){
			for(int j = 0; j < colNumA; j++){
				C.set(i, j, (A.get(i, j) + B.get(i, j)));
			}
		}
		return C;
		
	}
}
