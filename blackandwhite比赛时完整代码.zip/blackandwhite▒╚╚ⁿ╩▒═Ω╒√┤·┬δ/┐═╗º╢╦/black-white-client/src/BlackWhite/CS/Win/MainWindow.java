package BlackWhite.CS.Win;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Insets;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.util.Enumeration;
import java.util.regex.Pattern;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.border.BevelBorder;
import javax.swing.border.CompoundBorder;
import javax.swing.border.TitledBorder;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;
import javax.swing.plaf.FontUIResource;
import javax.swing.text.JTextComponent;
import BlackWhite.CS.ImageCS.CSensingHelp;
import BlackWhite.CS.ImageDecrypt.ImageDecryption;
import BlackWhite.CS.ProEncrypt.ProEncrypt;

public class MainWindow extends JFrame implements ActionListener, HyperlinkListener{
	JFileChooser jfc;
	JFileChooser jfc1;
	File imageFile;
	File txtFile;
	ImageIcon imgIco;
	ImageIcon txtIco;
	boolean hasChoosedImage = false;
	boolean hasChoosedTxt = false;
	/**
	 * Group Black and White 
	 * About Compressive Sensing Reconstruct
	 * This system is for users to upload encrypted images and decrypted images 
	 */
	private static final long serialVersionUID = 1L;

	JPanel imageDecryptPanel;
	JPanel panel,panel_3, panel_4, panel_5,panel_6,panel_7,panel_1,panel_2;
	private CardLayout cardLayout;
	private String card1,card2,card3,card4;
	
/*---------------------------------------------�ͻ����õ���ͼ��-------------------------------------------------*/
	private Icon main = new ImageIcon("icons/globes_black.png");
	private Icon cs = new ImageIcon("icons/globes_deepblue.png");
	private Icon decrypt = new ImageIcon("icons/globes_smokey.png");
	private Icon proEn = new ImageIcon("icons/globes_grey.png");
	private Icon imageChoose = new ImageIcon("icons/imageIcon.png");
	private Icon fileChoose = new ImageIcon("icons/fileIcon.png");
	private ImageIcon icon = new ImageIcon("icons/icon.png"); ;
/*---------------------------------------------�ͻ����������--------------------------------------------------*/
	private JPanel middleMainPanel;
	private JPasswordField mk1pwdBlack;
	private JPasswordField mk2pwdWhite;
	private JTextComponent csInfoTextArea;
	private JTextField waterTextField;
	private JPasswordField mk1PasswordField;
	private JPasswordField mk2PasswordField;
	private JTextArea fileTextArea;
	private JTextField proWaterTextField;
	private JPasswordField proPasswordField;
	private JPasswordField proPasswordField_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					new MainWindow();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public MainWindow() {
		File crateDocument = new File("C:/Users/TsengBiao/Desktop/","CS_Workshop");
		File crateDocument1 = new File("C:/Users/TsengBiao/Desktop/CS_Workshop/","file");
		File crateDocument2 = new File("C:/Users/TsengBiao/Desktop/CS_Workshop/","image");
		if(!crateDocument.exists()){
			crateDocument.mkdir();
		}
		if(!crateDocument1.exists()){
			crateDocument1.mkdir();
		}
		if(!crateDocument2.exists()){
			crateDocument2.mkdir();
		}
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		MenuBar();
		InitGlobalFont(new Font("����", Font.PLAIN, 14));
		setTitle("BLACK & WHITE");
		setSize(736, 600);
		setLocation(this.getToolkit().getScreenSize().width/2 - this.getWidth()/2, this.getToolkit().getScreenSize().height/2-this.getHeight()/2);
	    setIconImage(icon.getImage());  
		this.setVisible(true);
		jfc=new JFileChooser("./");
		jfc1=new JFileChooser("./");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		getContentPane().setLayout(new BorderLayout(0, 0));
		
		//��β
		JPanel footPanel = new JPanel();
		getContentPane().add(footPanel, BorderLayout.SOUTH);
		footPanel.setLayout(new GridLayout(0, 1, 0, 0));
		
		JLabel footLabel = new JLabel("@ Black & White Group Members");
		footLabel.setFont(new Font("΢���ź� Light", Font.PLAIN, 12));
		footPanel.add(footLabel);
		
		//�����ĸ�card���
		middleMainPanel = new JPanel();
		getContentPane().add(middleMainPanel, BorderLayout.CENTER);
		cardLayout = new CardLayout(0, 0);
		middleMainPanel.setLayout(cardLayout);
		
		//�����
		card1 = "name_14438194929903";
		JPanel mainCardPanel = new JPanel();
		middleMainPanel.add(mainCardPanel, "name_14438194929903");
		mainCardPanel.setLayout(new BorderLayout(0, 0));
		
		JPanel mainCardCenter = new JPanel();
		mainCardCenter.setBackground(new Color(38,50,86));
		mainCardPanel.add(mainCardCenter, BorderLayout.CENTER);
		mainCardCenter.setLayout(null);
		
		JLabel lblBlackWhite = new JLabel("BLACK & WHITE");
		lblBlackWhite.setForeground(new Color(255, 255, 255));
		lblBlackWhite.setFont(new Font("΢���ź�", Font.PLAIN, 30));
		lblBlackWhite.setBackground(new Color(255, 255, 255));
		lblBlackWhite.setBounds(25, 20, 235, 90);
		mainCardCenter.add(lblBlackWhite);
		
		JLabel label_8 = new JLabel("��Ʒ���");
		label_8.setForeground(new Color(255, 255, 255));
		label_8.setFont(new Font("΢���ź�", Font.PLAIN, 15));
		label_8.setBounds(178, 158, 82, 29);
		mainCardCenter.add(label_8);
		
		JLabel lblNewLabel_3 = new JLabel("����Ʒ��һ������ѹ����֪�İ�ȫ���������ϵ");
		lblNewLabel_3.setFont(new Font("΢���ź� Light", Font.PLAIN, 16));
		lblNewLabel_3.setForeground(new Color(255, 255, 255));
		lblNewLabel_3.setBounds(51, 197, 355, 41);
		mainCardCenter.add(lblNewLabel_3);
		
		JLabel lblweb = new JLabel("ͳ��ϵͳ�ɵ�ǰ�ı��ؿͻ��˼�web��վ��ɡ�����");
		lblweb.setForeground(new Color(255, 255, 255));
		lblweb.setFont(new Font("΢���ź� Light", Font.PLAIN, 16));
		lblweb.setBounds(25, 234, 381, 18);
		mainCardCenter.add(lblweb);
		
		JLabel label_17 = new JLabel("�ͻ�����Ҫ��ѹ���������ع��������ܣ��Լ�ͼ���");
		label_17.setForeground(new Color(255, 255, 255));
		label_17.setFont(new Font("΢���ź� Light", Font.PLAIN, 16));
		label_17.setBounds(25, 262, 381, 15);
		mainCardCenter.add(label_17);
		
		JLabel label_18 = new JLabel("��������鹹�ɡ�");
		label_18.setForeground(new Color(255, 255, 255));
		label_18.setFont(new Font("΢���ź� Light", Font.PLAIN, 16));
		label_18.setBounds(25, 287, 312, 15);
		mainCardCenter.add(label_18);
		
		//CS ���
		card2 = "name_14473438974177";
		JPanel csCardPanel = new JPanel();
		middleMainPanel.add(csCardPanel, card2);
		csCardPanel.setLayout(new BorderLayout(0, 0));
		
		JPanel csCardHead = new JPanel();
		csCardHead.setForeground(new Color(0, 0, 153));
		csCardHead.setBackground(new Color(0, 0, 51));
		csCardHead.setBorder(new CompoundBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null), null));
		csCardPanel.add(csCardHead, BorderLayout.NORTH);
		
		JLabel lblcs = new JLabel("ͼ��ѹ������");
		lblcs.setForeground(new Color(255, 255, 255));
		lblcs.setFont(new Font("΢���ź� Light", Font.PLAIN, 14));
		csCardHead.add(lblcs);
		
		JPanel csCardCenter = new JPanel();
		csCardCenter.setBackground(new Color(38,50,86));
		csCardPanel.add(csCardCenter, BorderLayout.CENTER);
		GridBagLayout gbl_csCardCenter = new GridBagLayout();
		gbl_csCardCenter.columnWidths = new int[]{123, 57, 299, 68, 0};
		gbl_csCardCenter.rowHeights = new int[]{0, 104, 37, 35, 35, 36, 36, 16, 12, 0};
		gbl_csCardCenter.columnWeights = new double[]{0.0, 0.0, 1.0, 0.0, Double.MIN_VALUE};
		gbl_csCardCenter.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		csCardCenter.setLayout(gbl_csCardCenter);
		
		JButton button = new JButton("ѡ��ͼ��");
		button.setForeground(new Color(0, 0, 0));
		button.setFont(new Font("΢���ź� Light", Font.PLAIN, 14));
		Image imageSelect = ((ImageIcon) imageChoose).getImage();  
		imageSelect = imageSelect.getScaledInstance(30, 30, Image.SCALE_DEFAULT); 
        ((ImageIcon) imageChoose).setImage(imageSelect);  
		button.setIcon(imageChoose);
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource() == button){
					//�����ϴδ�λ��
			            jfc.setCurrentDirectory(jfc.getCurrentDirectory());
			            //���ù���
			            jfc.setFileFilter(FileChooseTool.myFilter());
			            int result = jfc.showOpenDialog(button);
			            imageFile = jfc.getSelectedFile();
			            if( result == 0 && imageFile!=null) {
			            	hasChoosedImage = true;
			            	FileChooseTool.addFile(imageFile);
			                new getImageFileList(jfc.getCurrentDirectory()).start();
			                imgIco = new ImageIcon(imageFile.getPath());
			                try {
								showImageInfo();
							} catch (MalformedURLException e1) {
								e1.printStackTrace();
							} catch (IOException e1) {
								e1.printStackTrace();
							}
			            }
			           
					}
				}
				//��ͼ����Ϣ������ʾѡ��ͼƬ����Ϣ
				private void showImageInfo() throws MalformedURLException, IOException {			
					        @SuppressWarnings("deprecation")
							String msg="���ƣ�"+imageFile.getName()+"\n���ͣ�"+imageFile.toURL().openConnection().getContentType()+"\n�ߴ磺"+imgIco.getIconHeight()+" x "
					                +imgIco.getIconWidth()+"����"+"\n��С��"+ String.format("%.1f",imageFile.length()/1024.0)+"kb";			              
					        csInfoTextArea.setText(msg); 
				}
		});
		
		JLabel lblNewLabel = new JLabel(" ѡ�����ͼ��");
		lblNewLabel.setForeground(new Color(255, 255, 255));
		lblNewLabel.setFont(new Font("΢���ź� Light", Font.PLAIN, 14));
		GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
		gbc_lblNewLabel.fill = GridBagConstraints.BOTH;
		gbc_lblNewLabel.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel.gridx = 0;
		gbc_lblNewLabel.gridy = 0;
		csCardCenter.add(lblNewLabel, gbc_lblNewLabel);
		GridBagConstraints gbc_button = new GridBagConstraints();
		gbc_button.insets = new Insets(0, 0, 5, 5);
		gbc_button.gridx = 1;
		gbc_button.gridy = 1;
		csCardCenter.add(button, gbc_button);
		
		JPanel panel_9 = new JPanel();
		panel_9.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "ImageInfo", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		GridBagConstraints gbc_panel_9 = new GridBagConstraints();
		gbc_panel_9.fill = GridBagConstraints.BOTH;
		gbc_panel_9.insets = new Insets(0, 0, 5, 5);
		gbc_panel_9.gridx = 2;
		gbc_panel_9.gridy = 1;
		csCardCenter.add(panel_9, gbc_panel_9);
		GridBagLayout gbl_panel_9 = new GridBagLayout();
		gbl_panel_9.columnWidths = new int[]{299, 0};
		gbl_panel_9.rowHeights = new int[]{104, 0};
		gbl_panel_9.columnWeights = new double[]{1.0, Double.MIN_VALUE};
		gbl_panel_9.rowWeights = new double[]{0.0, Double.MIN_VALUE};
		panel_9.setLayout(gbl_panel_9);
		
		csInfoTextArea = new JTextArea();
		csInfoTextArea.setFont(new Font("΢���ź� Light", Font.PLAIN, 13));
		csInfoTextArea.setBackground(SystemColor.window);
		GridBagConstraints gbc_csInfoTextArea = new GridBagConstraints();
		gbc_csInfoTextArea.fill = GridBagConstraints.BOTH;
		gbc_csInfoTextArea.gridx = 0;
		gbc_csInfoTextArea.gridy = 0;
		panel_9.add(csInfoTextArea, gbc_csInfoTextArea);
		csInfoTextArea.setEditable(false);
		
		JLabel label_4 = new JLabel(" Ƕ���ˮӡ��Ϣ");
		label_4.setForeground(new Color(255, 255, 255));
		label_4.setFont(new Font("΢���ź� Light", Font.PLAIN, 14));
		GridBagConstraints gbc_label_4 = new GridBagConstraints();
		gbc_label_4.fill = GridBagConstraints.BOTH;
		gbc_label_4.insets = new Insets(0, 0, 5, 5);
		gbc_label_4.gridx = 0;
		gbc_label_4.gridy = 2;
		csCardCenter.add(label_4, gbc_label_4);
		
		JLabel label_9 = new JLabel("����ˮӡ��");
		label_9.setForeground(new Color(255, 255, 255));
		label_9.setFont(new Font("΢���ź� Light", Font.PLAIN, 14));
		GridBagConstraints gbc_label_9 = new GridBagConstraints();
		gbc_label_9.insets = new Insets(0, 0, 5, 5);
		gbc_label_9.gridx = 1;
		gbc_label_9.gridy = 3;
		csCardCenter.add(label_9, gbc_label_9);
		
		waterTextField = new JTextField();
		waterTextField.setFont(new Font("΢���ź� Light", Font.PLAIN, 13));
		GridBagConstraints gbc_waterTextField = new GridBagConstraints();
		gbc_waterTextField.insets = new Insets(0, 0, 5, 5);
		gbc_waterTextField.fill = GridBagConstraints.BOTH;
		gbc_waterTextField.gridx = 2;
		gbc_waterTextField.gridy = 3;
		csCardCenter.add(waterTextField, gbc_waterTextField);
		waterTextField.setColumns(10);
		
		JLabel label_5 = new JLabel(" ��������Կ");
		label_5.setForeground(new Color(255, 255, 255));
		label_5.setFont(new Font("΢���ź� Light", Font.PLAIN, 14));
		GridBagConstraints gbc_label_5 = new GridBagConstraints();
		gbc_label_5.fill = GridBagConstraints.VERTICAL;
		gbc_label_5.anchor = GridBagConstraints.WEST;
		gbc_label_5.insets = new Insets(0, 0, 5, 5);
		gbc_label_5.gridx = 0;
		gbc_label_5.gridy = 4;
		csCardCenter.add(label_5, gbc_label_5);
		
		JLabel label_6 = new JLabel("����Կ1��");
		label_6.setForeground(new Color(255, 255, 255));
		label_6.setFont(new Font("΢���ź� Light", Font.PLAIN, 14));
		GridBagConstraints gbc_label_6 = new GridBagConstraints();
		gbc_label_6.fill = GridBagConstraints.VERTICAL;
		gbc_label_6.insets = new Insets(0, 0, 5, 5);
		gbc_label_6.gridx = 1;
		gbc_label_6.gridy = 5;
		csCardCenter.add(label_6, gbc_label_6);
		
		mk1pwdBlack = new JPasswordField();
		mk1pwdBlack.setFont(new Font("΢���ź� Light", Font.PLAIN, 13));
		GridBagConstraints gbc_mk1pwdBlack = new GridBagConstraints();
		gbc_mk1pwdBlack.insets = new Insets(0, 0, 5, 5);
		gbc_mk1pwdBlack.fill = GridBagConstraints.BOTH;
		gbc_mk1pwdBlack.gridx = 2;
		gbc_mk1pwdBlack.gridy = 5;
		csCardCenter.add(mk1pwdBlack, gbc_mk1pwdBlack);
		
		JLabel label_7 = new JLabel("����Կ2��");
		label_7.setForeground(new Color(255, 255, 255));
		label_7.setFont(new Font("΢���ź� Light", Font.PLAIN, 14));
		GridBagConstraints gbc_label_7 = new GridBagConstraints();
		gbc_label_7.fill = GridBagConstraints.VERTICAL;
		gbc_label_7.insets = new Insets(0, 0, 5, 5);
		gbc_label_7.gridx = 1;
		gbc_label_7.gridy = 6;
		csCardCenter.add(label_7, gbc_label_7);
		
		mk2pwdWhite = new JPasswordField();
		mk2pwdWhite.setFont(new Font("΢���ź� Light", Font.PLAIN, 13));
		GridBagConstraints gbc_mk2pwdWhite = new GridBagConstraints();
		gbc_mk2pwdWhite.insets = new Insets(0, 0, 5, 5);
		gbc_mk2pwdWhite.fill = GridBagConstraints.BOTH;
		gbc_mk2pwdWhite.gridx = 2;
		gbc_mk2pwdWhite.gridy = 6;
		csCardCenter.add(mk2pwdWhite, gbc_mk2pwdWhite);
		
		JButton csYesBtn = new JButton("���ɲ���ֵ�ļ�");
		csYesBtn.setForeground(new Color(0, 0, 0));
		csYesBtn.setFont(new Font("΢���ź� Light", Font.PLAIN, 14));
		csYesBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				@SuppressWarnings("deprecation")
				String mk1 = mk1pwdBlack.getText();
				@SuppressWarnings("deprecation")
				String mk2 = mk2pwdWhite.getText();
				String waters = waterTextField.getText();
				if(!hasChoosedImage){
					JOptionPane.showMessageDialog(null,"��ѡ�����ͼƬ", "����ʧ��",JOptionPane.WARNING_MESSAGE);
				}
				else if(waterTextField.getText().equals("")){
					JOptionPane.showMessageDialog(null,"��Ƕ��ˮӡ", "����ʧ��",JOptionPane.WARNING_MESSAGE);
				}
				else if(!isRegular(waterTextField.getText())){
					JOptionPane.showMessageDialog(null,"ˮӡֻ�ܰ�����ĸ������", "����ʧ��",JOptionPane.WARNING_MESSAGE);
				}
				else if(mk1.equals("") ||mk2.equals("")){
					JOptionPane.showMessageDialog(null,"����Կ����Ϊ��", "����ʧ��",JOptionPane.WARNING_MESSAGE);
				}
				else if(!isRegular(mk1) || !isRegular(mk2)){
					JOptionPane.showMessageDialog(null,"��Կֻ�ܰ�����ĸ�����֡��ַ�", "����ʧ��",JOptionPane.WARNING_MESSAGE);
				}
				else{
					//����ѹ����֪���õ�����ֵ						
					try {
						csEncrypt(imageFile,waters, mk1, mk2, 1);
					} catch (IOException e1) {
						e1.printStackTrace();
					}
				}
	
			}
		});
		GridBagConstraints gbc_csYesBtn = new GridBagConstraints();
		gbc_csYesBtn.insets = new Insets(0, 0, 0, 5);
		gbc_csYesBtn.gridx = 2;
		gbc_csYesBtn.gridy = 8;
		csCardCenter.add(csYesBtn, gbc_csYesBtn);
		
		//�������
		card3 = "name_14495114581382";
		JPanel decryptCardPanel = new JPanel();
		decryptCardPanel.setBackground(new Color(0, 0, 51));
		middleMainPanel.add(decryptCardPanel, card3);
		decryptCardPanel.setLayout(new BorderLayout(0, 0));
		
		JPanel deCardHead = new JPanel();
		deCardHead.setBackground(new Color(0, 0, 51));
		deCardHead.setForeground(SystemColor.activeCaptionBorder);
		deCardHead.setBorder(new CompoundBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null), null));
		decryptCardPanel.add(deCardHead, BorderLayout.NORTH);
		
		JLabel label = new JLabel("�źŽ��ܼ�ͼ��ָ�");
		label.setForeground(new Color(255, 255, 255));
		label.setFont(new Font("΢���ź� Light", Font.PLAIN, 14));
		deCardHead.add(label);
		
		JPanel deCardCenter = new JPanel();
		deCardCenter.setBackground(new Color(38,50,86));
		decryptCardPanel.add(deCardCenter, BorderLayout.CENTER);
		GridBagLayout gbl_deCardCenter = new GridBagLayout();
		gbl_deCardCenter.columnWidths = new int[]{0, 0, 0, 62, 0};
		gbl_deCardCenter.rowHeights = new int[]{0, 36, 98, 29, 42, 29, 42, 20, 0, 0};
		gbl_deCardCenter.columnWeights = new double[]{0.0, 0.0, 1.0, 0.0, Double.MIN_VALUE};
		gbl_deCardCenter.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		deCardCenter.setLayout(gbl_deCardCenter);
		
		JLabel label_1 = new JLabel(" ѡ������ļ�");
		label_1.setForeground(new Color(255, 255, 255));
		label_1.setFont(new Font("΢���ź� Light", Font.PLAIN, 14));
		GridBagConstraints gbc_label_1 = new GridBagConstraints();
		gbc_label_1.anchor = GridBagConstraints.WEST;
		gbc_label_1.insets = new Insets(0, 0, 5, 5);
		gbc_label_1.gridx = 0;
		gbc_label_1.gridy = 0;
		deCardCenter.add(label_1, gbc_label_1);
		
		JLabel label_12 = new JLabel("�ļ���Ϣ");
		label_12.setForeground(new Color(255, 255, 255));
		label_12.setFont(new Font("΢���ź� Light", Font.PLAIN, 14));
		GridBagConstraints gbc_label_12 = new GridBagConstraints();
		gbc_label_12.insets = new Insets(0, 0, 5, 5);
		gbc_label_12.gridx = 2;
		gbc_label_12.gridy = 1;
		deCardCenter.add(label_12, gbc_label_12);
		
		JButton deChooseFile = new JButton("ѡ���ļ�");
		deChooseFile.setFont(new Font("΢���ź� Light", Font.PLAIN, 14));
		Image fileSelect = ((ImageIcon) fileChoose).getImage();  
		fileSelect = fileSelect.getScaledInstance(30, 30, Image.SCALE_DEFAULT); 
        ((ImageIcon) fileChoose).setImage(fileSelect); 
        deChooseFile.setIcon(fileChoose);
		deChooseFile.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource() == deChooseFile){
		            jfc1.setCurrentDirectory(jfc1.getCurrentDirectory());
		            //���ù���
		            jfc1.setFileFilter(FileChooseTool.myFilter1());
		            int result = jfc1.showOpenDialog(deChooseFile);
		            txtFile = jfc1.getSelectedFile();
		            if( result == 0 && txtFile!=null) {
		            	hasChoosedTxt = true;
		            	FileChooseTool.addFile(txtFile);
		                new getTxtFileList(jfc1.getCurrentDirectory()).start();
		                try {
							showTxtInfo();
						} catch (MalformedURLException e1) {
							e1.printStackTrace();
						} catch (IOException e1) {
							e1.printStackTrace();
						}
		            }
		           
				}
			}
			//��ͼ����Ϣ������ʾѡ��ͼƬ����Ϣ
			private void showTxtInfo() throws MalformedURLException, IOException {			
				        @SuppressWarnings("deprecation")
						String msg="���ƣ�"+txtFile.getName()+"\n���ͣ�"+txtFile.toURL().openConnection().getContentType()+
				                "\n��С��"+ String.format("%.1f",txtFile.length()/1024.0)+"kb";			              
				        fileTextArea.setText(msg); 
			}
		});
		GridBagConstraints gbc_deChooseFile = new GridBagConstraints();
		gbc_deChooseFile.insets = new Insets(0, 0, 5, 5);
		gbc_deChooseFile.gridx = 1;
		gbc_deChooseFile.gridy = 2;
		deCardCenter.add(deChooseFile, gbc_deChooseFile);
		
		JPanel panel_8 = new JPanel();
		panel_8.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "File Info", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		GridBagConstraints gbc_panel_8 = new GridBagConstraints();
		gbc_panel_8.fill = GridBagConstraints.BOTH;
		gbc_panel_8.insets = new Insets(0, 0, 5, 5);
		gbc_panel_8.gridx = 2;
		gbc_panel_8.gridy = 2;
		deCardCenter.add(panel_8, gbc_panel_8);
		GridBagLayout gbl_panel_8 = new GridBagLayout();
		gbl_panel_8.columnWidths = new int[]{0, 0};
		gbl_panel_8.rowHeights = new int[]{98, 0};
		gbl_panel_8.columnWeights = new double[]{1.0, Double.MIN_VALUE};
		gbl_panel_8.rowWeights = new double[]{0.0, Double.MIN_VALUE};
		panel_8.setLayout(gbl_panel_8);
		
		fileTextArea = new JTextArea();
		fileTextArea.setFont(new Font("΢���ź� Light", Font.PLAIN, 13));
		fileTextArea.setBackground(SystemColor.window);
		fileTextArea.setEditable(false);
		GridBagConstraints gbc_fileTextArea = new GridBagConstraints();
		gbc_fileTextArea.fill = GridBagConstraints.BOTH;
		gbc_fileTextArea.gridx = 0;
		gbc_fileTextArea.gridy = 0;
		panel_8.add(fileTextArea, gbc_fileTextArea);
		
		JLabel label_10 = new JLabel(" ��������Կ");
		label_10.setForeground(new Color(255, 255, 255));
		label_10.setFont(new Font("΢���ź� Light", Font.PLAIN, 14));
		GridBagConstraints gbc_label_10 = new GridBagConstraints();
		gbc_label_10.anchor = GridBagConstraints.WEST;
		gbc_label_10.insets = new Insets(0, 0, 5, 5);
		gbc_label_10.gridx = 0;
		gbc_label_10.gridy = 3;
		deCardCenter.add(label_10, gbc_label_10);
		
		JLabel label_13 = new JLabel("����Կ1��");
		label_13.setForeground(new Color(255, 255, 255));
		label_13.setFont(new Font("΢���ź� Light", Font.PLAIN, 14));
		GridBagConstraints gbc_label_13 = new GridBagConstraints();
		gbc_label_13.fill = GridBagConstraints.VERTICAL;
		gbc_label_13.insets = new Insets(0, 0, 5, 5);
		gbc_label_13.gridx = 1;
		gbc_label_13.gridy = 4;
		deCardCenter.add(label_13, gbc_label_13);
		
		mk1PasswordField = new JPasswordField();
		mk1PasswordField.setFont(new Font("΢���ź� Light", Font.PLAIN, 13));
		GridBagConstraints gbc_mk1PasswordField = new GridBagConstraints();
		gbc_mk1PasswordField.insets = new Insets(0, 0, 5, 5);
		gbc_mk1PasswordField.fill = GridBagConstraints.BOTH;
		gbc_mk1PasswordField.gridx = 2;
		gbc_mk1PasswordField.gridy = 4;
		deCardCenter.add(mk1PasswordField, gbc_mk1PasswordField);
		
		JLabel label_14 = new JLabel("����Կ2��");
		label_14.setForeground(new Color(255, 255, 255));
		label_14.setFont(new Font("΢���ź� Light", Font.PLAIN, 14));
		GridBagConstraints gbc_label_14 = new GridBagConstraints();
		gbc_label_14.insets = new Insets(0, 0, 5, 5);
		gbc_label_14.gridx = 1;
		gbc_label_14.gridy = 6;
		deCardCenter.add(label_14, gbc_label_14);
		
		mk2PasswordField = new JPasswordField();
		mk2PasswordField.setFont(new Font("΢���ź� Light", Font.PLAIN, 13));
		GridBagConstraints gbc_mk2PasswordField = new GridBagConstraints();
		gbc_mk2PasswordField.insets = new Insets(0, 0, 5, 5);
		gbc_mk2PasswordField.fill = GridBagConstraints.BOTH;
		gbc_mk2PasswordField.gridx = 2;
		gbc_mk2PasswordField.gridy = 6;
		deCardCenter.add(mk2PasswordField, gbc_mk2PasswordField);
		
		JButton deSureBtn = new JButton("ͼ��ָ�");
		deSureBtn.setFont(new Font("΢���ź� Light", Font.PLAIN, 14));
		deSureBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				@SuppressWarnings("deprecation")
				String mk1 = mk1PasswordField.getText();
				@SuppressWarnings("deprecation")
				String mk2 = mk2PasswordField.getText();
				if(!hasChoosedTxt){
					JOptionPane.showMessageDialog(null,"��ѡ������ļ�", "����ʧ��",JOptionPane.WARNING_MESSAGE);
				}
				else if(mk1.equals("")||mk2.equals("")){
					JOptionPane.showMessageDialog(null,"����Կ����Ϊ��", "����ʧ��",JOptionPane.WARNING_MESSAGE);
				}
				else{
					//���ܹ���						
					try {
						ImageDecryption.imageDecrypt(txtFile, mk1, mk2);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
					
				}	
			}
		});
		GridBagConstraints gbc_deSureBtn = new GridBagConstraints();
		gbc_deSureBtn.insets = new Insets(0, 0, 0, 5);
		gbc_deSureBtn.gridx = 2;
		gbc_deSureBtn.gridy = 8;
		deCardCenter.add(deSureBtn, gbc_deSureBtn);
		
		//����������
		card4 = "name_14484159256275";
		JPanel peoEnCardPanel = new JPanel();
		middleMainPanel.add(peoEnCardPanel, card4);
		peoEnCardPanel.setLayout(new BorderLayout(0, 0));
		
		JPanel proEnCardHead = new JPanel();
		proEnCardHead.setBackground(new Color(0, 0, 51));
		proEnCardHead.setBorder(new CompoundBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null), null));
		peoEnCardPanel.add(proEnCardHead, BorderLayout.NORTH);
		
		JLabel lblNewLabel_1 = new JLabel("����Ҫ��֤��ˮӡ�ļ������ܵ�Phi�ļ�");
		lblNewLabel_1.setForeground(new Color(255, 255, 255));
		lblNewLabel_1.setFont(new Font("΢���ź� Light", Font.PLAIN, 14));
		proEnCardHead.add(lblNewLabel_1);
		
		JPanel proEnCardCenter = new JPanel();
		proEnCardCenter.setBackground(new Color(38,50,86));
		peoEnCardPanel.add(proEnCardCenter, BorderLayout.CENTER);
		GridBagLayout gbl_proEnCardCenter = new GridBagLayout();
		gbl_proEnCardCenter.columnWidths = new int[]{0, 0, 0, 71, 0};
		gbl_proEnCardCenter.rowHeights = new int[]{0, 30, 40, 34, 35, 42, 40, 41, 32, 0, 0};
		gbl_proEnCardCenter.columnWeights = new double[]{0.0, 0.0, 1.0, 0.0, Double.MIN_VALUE};
		gbl_proEnCardCenter.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		proEnCardCenter.setLayout(gbl_proEnCardCenter);
		
		JLabel label_2 = new JLabel(" ��֤ˮӡ");
		label_2.setForeground(new Color(255, 255, 255));
		label_2.setFont(new Font("΢���ź� Light", Font.PLAIN, 14));
		GridBagConstraints gbc_label_2 = new GridBagConstraints();
		gbc_label_2.insets = new Insets(0, 0, 5, 5);
		gbc_label_2.gridx = 0;
		gbc_label_2.gridy = 1;
		proEnCardCenter.add(label_2, gbc_label_2);
		
		JLabel label_3 = new JLabel("ˮӡ��Ϣ��");
		label_3.setForeground(new Color(255, 255, 255));
		label_3.setFont(new Font("΢���ź� Light", Font.PLAIN, 14));
		GridBagConstraints gbc_label_3 = new GridBagConstraints();
		gbc_label_3.insets = new Insets(0, 0, 5, 5);
		gbc_label_3.anchor = GridBagConstraints.EAST;
		gbc_label_3.gridx = 1;
		gbc_label_3.gridy = 2;
		proEnCardCenter.add(label_3, gbc_label_3);
		
		proWaterTextField = new JTextField();
		proWaterTextField.setFont(new Font("΢���ź� Light", Font.PLAIN, 13));
		GridBagConstraints gbc_proWaterTextField = new GridBagConstraints();
		gbc_proWaterTextField.insets = new Insets(0, 0, 5, 5);
		gbc_proWaterTextField.fill = GridBagConstraints.BOTH;
		gbc_proWaterTextField.gridx = 2;
		gbc_proWaterTextField.gridy = 2;
		proEnCardCenter.add(proWaterTextField, gbc_proWaterTextField);
		proWaterTextField.setColumns(10);
		
		JLabel label_15 = new JLabel(" ��������Կ");
		label_15.setForeground(new Color(255, 255, 255));
		label_15.setFont(new Font("΢���ź� Light", Font.PLAIN, 14));
		GridBagConstraints gbc_label_15 = new GridBagConstraints();
		gbc_label_15.insets = new Insets(0, 0, 5, 5);
		gbc_label_15.gridx = 0;
		gbc_label_15.gridy = 4;
		proEnCardCenter.add(label_15, gbc_label_15);
		
		JLabel lblNewLabel_2 = new JLabel("����Կ1��");
		lblNewLabel_2.setForeground(new Color(255, 255, 255));
		lblNewLabel_2.setFont(new Font("΢���ź� Light", Font.PLAIN, 14));
		GridBagConstraints gbc_lblNewLabel_2 = new GridBagConstraints();
		gbc_lblNewLabel_2.anchor = GridBagConstraints.EAST;
		gbc_lblNewLabel_2.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_2.gridx = 1;
		gbc_lblNewLabel_2.gridy = 5;
		proEnCardCenter.add(lblNewLabel_2, gbc_lblNewLabel_2);
		
		proPasswordField = new JPasswordField();
		proPasswordField.setFont(new Font("΢���ź� Light", Font.PLAIN, 13));
		GridBagConstraints gbc_proPasswordField = new GridBagConstraints();
		gbc_proPasswordField.insets = new Insets(0, 0, 5, 5);
		gbc_proPasswordField.fill = GridBagConstraints.BOTH;
		gbc_proPasswordField.gridx = 2;
		gbc_proPasswordField.gridy = 5;
		proEnCardCenter.add(proPasswordField, gbc_proPasswordField);
		
		JLabel label_16 = new JLabel("����Կ2��");
		label_16.setForeground(new Color(255, 255, 255));
		label_16.setFont(new Font("΢���ź� Light", Font.PLAIN, 14));
		GridBagConstraints gbc_label_16 = new GridBagConstraints();
		gbc_label_16.anchor = GridBagConstraints.EAST;
		gbc_label_16.insets = new Insets(0, 0, 5, 5);
		gbc_label_16.gridx = 1;
		gbc_label_16.gridy = 7;
		proEnCardCenter.add(label_16, gbc_label_16);
		
		JButton proSureBtn = new JButton("\u751F\u6210\u6C34\u5370\u53CAPhi\u6587\u4EF6");
		proSureBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String water = proWaterTextField.getText();
				@SuppressWarnings("deprecation")
				String mk1 = proPasswordField.getText();
				@SuppressWarnings("deprecation")
				String mk2 = proPasswordField_1.getText();
				if(water.equals("")){
					JOptionPane.showMessageDialog(null,"������ˮӡ", "����ʧ��",JOptionPane.WARNING_MESSAGE);
				}
				else if(!isRegular(water)){
					JOptionPane.showMessageDialog(null,"ˮӡֻ�ܰ�����ĸ������", "����ʧ��",JOptionPane.WARNING_MESSAGE);
				}
				else if(mk1.equals("") ||mk2.equals("")){
					JOptionPane.showMessageDialog(null,"����Կ����Ϊ��", "����ʧ��",JOptionPane.WARNING_MESSAGE);
				}
				else if(!isRegular(mk1) || !isRegular(mk2)){
					JOptionPane.showMessageDialog(null,"��Կֻ�ܰ�����ĸ�����֡��ַ�", "����ʧ��",JOptionPane.WARNING_MESSAGE);
				}
				proEncrypt(water, mk1, mk2, CSensingHelp.DEFAULT_BLOCKSIZE);
				
			}
		});
		
		proPasswordField_1 = new JPasswordField();
		proPasswordField_1.setFont(new Font("΢���ź� Light", Font.PLAIN, 13));
		GridBagConstraints gbc_proPasswordField_1 = new GridBagConstraints();
		gbc_proPasswordField_1.insets = new Insets(0, 0, 5, 5);
		gbc_proPasswordField_1.fill = GridBagConstraints.BOTH;
		gbc_proPasswordField_1.gridx = 2;
		gbc_proPasswordField_1.gridy = 7;
		proEnCardCenter.add(proPasswordField_1, gbc_proPasswordField_1);
		proSureBtn.setFont(new Font("΢���ź� Light", Font.PLAIN, 14));
		GridBagConstraints gbc_proSureBtn = new GridBagConstraints();
		gbc_proSureBtn.insets = new Insets(0, 0, 0, 5);
		gbc_proSureBtn.gridx = 2;
		gbc_proSureBtn.gridy = 9;
		proEnCardCenter.add(proSureBtn, gbc_proSureBtn);
		
		JPanel headerPanel = new JPanel();
		getContentPane().add(headerPanel, BorderLayout.NORTH);
		headerPanel.setLayout(new GridLayout(0, 4, 0, 0));
		
		Image img = ((ImageIcon) main).getImage();  
        img = img.getScaledInstance(30, 30, Image.SCALE_DEFAULT); 
        ((ImageIcon) main).setImage(img);  
        
		Image img1 = ((ImageIcon) cs).getImage();  
        img1 = img1.getScaledInstance(30, 30, Image.SCALE_DEFAULT); 
        ((ImageIcon) cs).setImage(img1);  
        
		Image img2 = ((ImageIcon) decrypt).getImage();  
        img2 = img2.getScaledInstance(30, 30, Image.SCALE_DEFAULT); 
        ((ImageIcon) decrypt).setImage(img2); 
        
		Image img3 = ((ImageIcon) proEn).getImage();  
        img3 = img3.getScaledInstance(30, 30, Image.SCALE_DEFAULT); 
        ((ImageIcon) proEn).setImage(img3); 
        
		JButton mainBtn = new JButton("������");
		mainBtn.setFont(new Font("΢���ź� Light", Font.PLAIN, 14));
		
		mainBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cardLayout.show(middleMainPanel, card1);
			}
		});
		mainBtn.setIcon(main);
		headerPanel.add(mainBtn);
		
		JButton csBtn = new JButton("ѹ������");
		csBtn.setFont(new Font("΢���ź� Light", Font.PLAIN, 14));
		csBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cardLayout.show(middleMainPanel, card2);
				
			}
		});
		csBtn.setIcon(cs);
		headerPanel.add(csBtn);
		
		JButton proEnBtn = new JButton("��������");
		proEnBtn.setFont(new Font("΢���ź� Light", Font.PLAIN, 14));
		proEnBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cardLayout.show(middleMainPanel, card4);
			}
		});
		proEnBtn.setIcon(proEn);
		headerPanel.add(proEnBtn);
		
		JButton deBtn = new JButton("ͼ��ָ�");
		deBtn.setFont(new Font("΢���ź� Light", Font.PLAIN, 14));
		deBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cardLayout.show(middleMainPanel, card3);
			}
		});
		deBtn.setIcon(decrypt);
		headerPanel.add(deBtn);
	}
	
	/*
	 * Menu 
	 */
	public void MenuBar() {
		JMenuBar menuBar = new JMenuBar();
		menuBar.setBackground(UIManager.getColor("Button.light"));
		menuBar.setMargin(new Insets(1, 1, 1, 1));
		JMenu fileMenu = new JMenu("�ļ�");
		fileMenu.setFont(new Font("΢���ź� Light", Font.PLAIN, 15));
		
		JMenu aboutMenu = new JMenu("����");
		aboutMenu.setFont(new Font("΢���ź� Light", Font.PLAIN, 15));
		fileMenu.setMnemonic(KeyEvent.VK_F);
		JMenuItem fileExitMenuItem = new JMenuItem("�˳�", KeyEvent.VK_X);
		fileExitMenuItem.setFont(new Font("΢���ź� Light", Font.PLAIN, 15));
		JMenuItem useMenuItem = new JMenuItem("ʹ��˵��");
		useMenuItem.setFont(new Font("΢���ź� Light", Font.PLAIN, 15));
		
		JMenuItem aboutMenuItem = new JMenuItem("�ͻ��˽���");
		aboutMenuItem.setFont(new Font("΢���ź� Light", Font.PLAIN, 15));
		
		JMenuItem mainWinMenuBtn = new JMenuItem("\u4E3B\u754C\u9762", KeyEvent.VK_X);
		mainWinMenuBtn.setFont(new Font("΢���ź� Light", Font.PLAIN, 15));
		
		JMenuItem CSMenuBtn = new JMenuItem("\u538B\u7F29\u91C7\u6837", KeyEvent.VK_X);
		CSMenuBtn.setFont(new Font("΢���ź� Light", Font.PLAIN, 15));
		
		fileMenu.add(mainWinMenuBtn);
		fileMenu.add(fileMenu.add(CSMenuBtn));
		aboutMenu.add(useMenuItem);
		aboutMenu.add(aboutMenuItem);
		menuBar.add(fileMenu);
		menuBar.add(aboutMenu);
		setJMenuBar(menuBar);
		
		JMenuItem paraEnMenuBtn = new JMenuItem("\u53C2\u6570\u52A0\u5BC6");
		paraEnMenuBtn.setFont(new Font("Microsoft YaHei UI Light", Font.PLAIN, 15));
		fileMenu.add(paraEnMenuBtn);
		
		JMenuItem imageReMenuBtn = new JMenuItem("\u56FE\u50CF\u6062\u590D");
		imageReMenuBtn.setFont(new Font("Microsoft YaHei UI Light", Font.PLAIN, 15));
		fileMenu.add(imageReMenuBtn);
		fileMenu.add(fileExitMenuItem);
		
		JMenu helpMenu = new JMenu("\u5E2E\u52A9");
		menuBar.add(helpMenu);
		helpMenu.setFont(new Font("΢���ź� Light", Font.PLAIN, 15));
		JMenuItem helpMenuItem = new JMenuItem("\u4F7F\u7528\u8BF4\u660E");
		helpMenuItem.setFont(new Font("΢���ź� Light", Font.PLAIN, 15));
		helpMenu.add(helpMenuItem); 
		
		//�ļ�-�˳���ť
		fileExitMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		//�ļ�-�����水ť
		mainWinMenuBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cardLayout.show(middleMainPanel, card1);
			}
		});
		//�ļ�-ѹ��������ť
		CSMenuBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cardLayout.show(middleMainPanel, card2);
			}
		});
		//�ļ�-�������ܰ�ť
		paraEnMenuBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cardLayout.show(middleMainPanel, card4);
			}
		});
		//�ļ�-ͼ��ָ���ť
		imageReMenuBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cardLayout.show(middleMainPanel, card3);
			}
		});
		//ʹ�ð�ť
		useMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, "ͼ��ѹ��������ѡ�����ͼ������ˮӡ��Ϣ������Կ�����ɲ���ֵ�ļ�\n"+
						"������ܣ�����ˮӡ��Ϣ������Կ������ˮӡ��Ϣ�����ܲ���\n"
						+"ͼ��ָ���ѡ������ļ�����������Կ���ָ�ԭͼ","ʹ��˵��",JOptionPane.WARNING_MESSAGE);
			}
		});
		//���ڿͻ���
		aboutMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, "����Ʒ�����ǻ���ѹ����֪�İ�ȫ���������\n"
						+ "ϵͳ����ϵͳ����Ҫ����ͼ��ѹ���������ع�\n"
						+ "������ܣ��Լ�ͼ��ָ�����ģ��","�ͻ���˵��",JOptionPane.WARNING_MESSAGE);
			}
		});
	
	}
	

	/**
	 * �����������
	 * @param water
	 * @param mk1
	 * @param mk2
	 * @param signalLength
	 */
	protected void proEncrypt(String water, String mk1, String mk2,int signalLength) {
		ProEncrypt.problemEncrypt(water,mk1,mk2,signalLength);
	}
	
	/**
	 * @param text
	 * @return boolean whether watermark is avialiable
	 */
	protected boolean isRegular(String text) {
	    // ˮӡ��֤����
	    String regEx = "[a-z0-9A-Z]*";
	    // �����������ʽ
	    Pattern pattern = Pattern.compile(regEx);
	    java.util.regex.Matcher matcher = pattern.matcher(text);
	    
	    // �ַ����Ƿ����������ʽ��ƥ��
	    boolean rs = matcher.matches();
		return rs;
	}
	
	/**
	 * ���ܹ��̣�CS���̣��������ĵ���Ų���ֵY
	 * @param imageFile ͼ���ļ�
	 * @param imageFileWater ˮӡͼ���ļ�
	 * @param mk1 ����Կ1
	 * @param mk2 ����Կ2
	 * @param order ͼ��˳�� Ĭ��ֵΪ1
	 * @throws IOException
	 */
	protected void csEncrypt(File imageFile, String water, String mk1, String mk2, int order) throws IOException {
		String imagePath = imageFile.getAbsolutePath();
		CSensingHelp.csImageBlock(imagePath,mk1,mk2,water);
	}
	
	//ͳһ
	private static void InitGlobalFont(Font font) {  
		  FontUIResource fontRes = new FontUIResource(font);  
		  for (Enumeration<Object> keys = UIManager.getDefaults().keys();  
		  keys.hasMoreElements(); ) {  
		  Object key = keys.nextElement();  
		  Object value = UIManager.get(key);  
		  if (value instanceof FontUIResource) {  
		  UIManager.put(key, fontRes);  
		  }  
	}  
		  
	}
	//�ڲ��� ͼ���ļ��б�
	public class getImageFileList extends Thread {
	    File CurrentDirectory;
	    public getImageFileList(File f){
	        this.CurrentDirectory=f;
	    }

	    public void run(){
	        File[] cd=CurrentDirectory.listFiles(FileChooseTool.myFilenameFilter());
	        for(int i=0;i<cd.length;i++){
	        	FileChooseTool.addFile(cd[i]);
	        }
	    }
	}
	//�ڲ��� �ĵ��ļ��б�
	public class getTxtFileList extends Thread {
	    File CurrentDirectory;
	    public getTxtFileList(File f){
	        this.CurrentDirectory=f;
	    }

	    public void run(){
	        File[] cd=CurrentDirectory.listFiles(FileChooseTool.myFilenameFilter1());
	        for(int i=0;i<cd.length;i++){
	        	FileChooseTool.addFile(cd[i]);
	        }
	    }
	}
	@Override
	public void hyperlinkUpdate(HyperlinkEvent e) {
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
	}
}
