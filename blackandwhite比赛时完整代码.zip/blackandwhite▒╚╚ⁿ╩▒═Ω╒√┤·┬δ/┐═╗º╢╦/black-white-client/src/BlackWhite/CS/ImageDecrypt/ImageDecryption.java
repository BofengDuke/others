package BlackWhite.CS.ImageDecrypt;

import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

import javax.imageio.ImageIO;
import javax.swing.JOptionPane;

import org.apache.mahout.math.Matrix;
import org.apache.mahout.math.SparseMatrix;

import BlackWhite.CS.ImageCS.CSensingHelp;
import BlackWhite.CS.ImageCS.ImageDCT;
import BlackWhite.CS.Matrix.MatrixHelper;
import net.sf.json.JSONObject;

public class ImageDecryption {
	public static final String WRITE_IMAGE = "C:/Users/TsengBiao/Desktop/CS_Workshop/image/";
	/**
	 * @param encryptedS
	 * @param mk1
	 * @param mk2
	 * @throws Exception 
	 */
	public static void imageDecrypt(File encryptedS, String mk1, String mk2) throws Exception{
		long tDeReadJson1 = System.currentTimeMillis();
		Matrix[] siganlDouble = siganlFromJsonFile(encryptedS);
		long tDeReadJson2 = System.currentTimeMillis();
		System.out.println("��ȡ������Ϣ�ļ���"+(tDeReadJson2-tDeReadJson1)+"ms");
		int [] randomSequence = CSensingHelp.getRandomSequence(mk1, CSensingHelp.DEFAULT_ITH_IMAGE, mk2, CSensingHelp.DEFAULT_BLOCKSIZE);
		Matrix encryptMatrix = CSensingHelp.encryptMatrix(randomSequence);
		
		getFinalImage(encryptMatrix,siganlDouble);
		JOptionPane.showMessageDialog(null,"���ܳɹ���ͼ�񱣴���imagesĿ¼�£�", "������ȷ��",JOptionPane.WARNING_MESSAGE);
		long tRecovery2 = System.currentTimeMillis();
		System.out.println("�ָ�ͼ��"+(tRecovery2-tDeReadJson2)+"ms");
	}

	
	/**
	 * @param encryptedS
	 * @return �ع��ź�S����
	 */
	private static Matrix[] siganlFromJsonFile(File encryptedS) {
		String lastArr = "";
		 try {  
	            BufferedReader br = new BufferedReader(new FileReader(encryptedS));// ��ȡԭʼjson�ļ�   
	            String s = null; 
	            while ((s = br.readLine()) != null) {  
	            	lastArr += s;
	            }  	 
	            br.close();  	  
	        } catch (IOException e) {  
	            e.printStackTrace();  
	        }
		 
		 JSONObject  jsonObj  = JSONObject.fromObject(lastArr);
//		 System.out.println(jsonObj);
		 
		 int len = jsonObj.size();
		 System.out.println(len);
		 Matrix tempS[] = new Matrix[len];
		 for(int i=0; i<len; i++){
			 tempS[i] = new SparseMatrix(CSensingHelp.DEFAULT_BLOCKSIZE,CSensingHelp.DEFAULT_BLOCKSIZE);
			 String temp = jsonObj.getString(Integer.toString(i+1));
			 
//			 System.out.println(temp);
			 String[] rowValues = temp.split("\n");
			 for(int j=0; j<rowValues.length; j++){
				 String[] colValues = rowValues[j].split("\t");
				 for(int k=0; k<colValues.length; k++){
					 tempS[i].set(j, k, Double.parseDouble(colValues[k]));
				 }	
			 }
			 
			// MatrixHelper.printMatrix(tempS[i]);
		 }
		 
		return tempS;
	}
	
	/**
	 * ����ͼ��
	 * @param encryptMatrix
	 * @param S
	 * @throws Exception
	 */
	public static void getFinalImage(Matrix encryptMatrix, Matrix[] S) throws Exception{
		int fianlSize = (int) (Math.sqrt(S.length)*CSensingHelp.DEFAULT_BLOCKSIZE);
		double[][] cons = new double[fianlSize][fianlSize];
		double[][] undecrypt = new double[fianlSize][fianlSize];
		double[][] finalImage = new double[fianlSize][fianlSize];
		int numOfBlockImage = S.length;
		int munOfWidth = (int) Math.sqrt(numOfBlockImage);
		for(int i=0; i<munOfWidth; i++){
			for(int j=0; j<munOfWidth; j++){
				double[][] idctSi2 = MatrixHelper.matrixToDouble((S[i*munOfWidth+j]));
				double[][] idctSi = ImageDCT.idct2(MatrixHelper.matrixToDouble((S[i*munOfWidth+j])), 0);
				double[][] idctSi1 = ImageDCT.idct2(MatrixHelper.matrixToDouble(encryptMatrix.times(S[i*munOfWidth+j])), 0);
				for(int l=0; l<CSensingHelp.DEFAULT_BLOCKSIZE; l++){
					for(int k=0; k<CSensingHelp.DEFAULT_BLOCKSIZE; k++){
						cons[i*CSensingHelp.DEFAULT_BLOCKSIZE+l][j*CSensingHelp.DEFAULT_BLOCKSIZE+k] = idctSi2[l][k];
						finalImage[i*CSensingHelp.DEFAULT_BLOCKSIZE+l][j*CSensingHelp.DEFAULT_BLOCKSIZE+k] = idctSi1[l][k];
						undecrypt[i*CSensingHelp.DEFAULT_BLOCKSIZE+l][j*CSensingHelp.DEFAULT_BLOCKSIZE+k] = idctSi[l][k];
					}
				}
			}
			
		}
		ImageIO.write(ArrayInt2Image(cons), "jpg", new File(WRITE_IMAGE+"sparseSignal"+".jpg"));
		ImageIO.write(ArrayInt2Image(undecrypt), "jpg", new File(WRITE_IMAGE+"undecrypt"+".jpg"));
		BufferedImage image = ArrayInt2Image(finalImage);
		ImageIO.write(image, "jpg", new File(WRITE_IMAGE+"reconstruct"+".jpg"));
	}
	
	/**
	 * @param data
	 * @return ͼ����
	 */
	public static BufferedImage ArrayInt2Image(double data[][]){
	    if(data!=null){
	        BufferedImage br=new BufferedImage(data[0].length, data.length, BufferedImage.TYPE_INT_RGB);
	        for(int i=0;i<data.length;i++){
	            for(int j=0;j<data[i].length;j++){
	            	int pixel =0;
					int B = (int)data[i][j];
					int G = B << 8;
					int R = B << 16;
					pixel = R + G + B;
	                br.setRGB(i, j, pixel);//��������
	            }
	        }
	        return br;
	    }
	    return null;
	}
	
	/**
	 * @param encryptedS
	 * @return encrypted file that contains n*n sparase signal
	 */
	@SuppressWarnings("unused")
	private static double[][] siganlFromFile(File encryptedS) {
		String filePath = encryptedS.getAbsolutePath();

		Scanner sFile = null;
		try {
			sFile = new Scanner(new FileReader(filePath));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		ArrayList<Double> sianal = new ArrayList<Double>();
		while(sFile.hasNextLine()){
			String strLine = sFile.nextLine();//��ȡһ��
			double tempDigit = Double.valueOf(strLine);
			sianal.add(tempDigit);
		}
		
		int lenOfSiganl = sianal.size();
		int scaleOfImageN = (int) Math.sqrt(lenOfSiganl);
		
		double[][] resultSianal = new double[scaleOfImageN][scaleOfImageN];
		for(int k=0; k< scaleOfImageN; k++){
			for(int j=0;j<scaleOfImageN;j++){
				double temp = sianal.get(k*scaleOfImageN+j);
				resultSianal[k][j] = temp;
			}
		}
		
		return resultSianal;
	}

	
}
